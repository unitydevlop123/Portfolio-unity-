<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Start Your Project - UnityDev</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .notification-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(5, 5, 15, 0.6);
            backdrop-filter: blur(25px) saturate(200%);
            -webkit-backdrop-filter: blur(25px) saturate(200%);
            z-index: 100000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .notification-overlay.active {
            display: flex;
        }
        .notification-flyer {
            width: 90%;
            max-width: 320px;
            background: linear-gradient(145deg, rgba(22, 33, 62, 0.95), rgba(10, 10, 26, 0.98));
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 2.5rem 1.5rem 2rem;
            text-align: center;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 
                0 20px 50px -10px rgba(0, 0, 0, 0.9),
                inset 0 0 20px rgba(0, 3, 255, 0.2);
            transform: translateY(100px) scale(0.8) rotateX(-20deg);
            opacity: 0;
            overflow: hidden;
        }
        .notification-overlay.active .notification-flyer {
            animation: flyerMegaEntrance 0.8s cubic-bezier(0.22, 1, 0.36, 1) forwards;
        }
        @keyframes flyerMegaEntrance {
            0% { transform: translateY(100px) scale(0.8) rotateX(-20deg); opacity: 0; }
            100% { transform: translateY(0) scale(1) rotateX(0); opacity: 1; }
        }
        
        .flyer-bg-drawing {
            position: absolute;
            inset: 0;
            z-index: -1;
            opacity: 0.4;
            pointer-events: none;
        }
        .flyer-bg-drawing svg {
            width: 100%;
            height: 100%;
        }
        .drawing-path {
            stroke-dasharray: 1000;
            stroke-dashoffset: 1000;
            animation: drawPath 3s ease forwards;
        }
        @keyframes drawPath {
            to { stroke-dashoffset: 0; }
        }
        .flyer-scanner {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, transparent, rgba(0, 212, 255, 0.5), transparent);
            animation: scanMove 4s linear infinite;
            box-shadow: 0 0 15px rgba(0, 212, 255, 0.5);
            z-index: 1;
        }
        @keyframes scanMove {
            0% { top: 0; opacity: 0; }
            10%, 90% { opacity: 1; }
            100% { top: 100%; opacity: 0; }
        }
        .flyer-illustration-container {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .illustration-main {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 0 15px rgba(0, 3, 255, 0.6));
            animation: floatIllustration 4s ease-in-out infinite;
        }
        @keyframes floatIllustration {
            0%, 100% { transform: translateY(0) rotate(0); }
            50% { transform: translateY(-10px) rotate(5deg); }
        }
        .illustration-orbit {
            position: absolute;
            width: 110px;
            height: 110px;
            border: 1px dashed rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            animation: rotateOrbit 15s linear infinite;
        }
        @keyframes rotateOrbit {
            from { transform: rotate(0); }
            to { transform: rotate(360deg); }
        }
        .orbit-dot {
            position: absolute;
            top: -5px;
            left: 50%;
            width: 10px;
            height: 10px;
            background: #44D8BD;
            border-radius: 50%;
            box-shadow: 0 0 15px #44D8BD;
        }
        .flyer-title {
            font-size: 1.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #fff 0%, #b8b8b8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        .flyer-text {
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 1.5rem;
            line-height: 1.6;
            font-size: 0.95rem;
            font-weight: 400;
        }
        .flyer-btn {
            width: 100%;
            padding: 1rem;
            border-radius: 18px;
            background: linear-gradient(135deg, #0003ff 0%, #9657f6 100%);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            margin-bottom: 0.5rem;
        }
        .flyer-btn:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0, 3, 255, 0.6);
            border-color: rgba(255,255,255,0.6);
        }
        .btn-shine {
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            animation: btnShine 3s infinite;
        }
        @keyframes btnShine {
            0% { left: -100%; }
            20% { left: 100%; }
            100% { left: 100%; }
        }

        .brief-page-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #05050f;
            z-index: 100001;
            display: none;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.6s cubic-bezier(0.22, 1, 0.36, 1);
            padding: 20px;
            overflow-y: auto;
        }
        .brief-page-overlay.active {
            display: block;
            opacity: 1;
            transform: translateX(0);
        }
        .brief-container {
            max-width: 800px;
            margin: 40px auto;
            background: linear-gradient(145deg, rgba(22, 33, 62, 0.4), rgba(10, 10, 26, 0.6));
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        }
        .brief-display {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
            color: #ffffff;
            font-family: 'Inter', sans-serif;
            white-space: pre-wrap;
            font-size: 1.1rem;
            line-height: 1.8;
        }
        .brief-footer-actions {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .action-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .big-btn {
            padding: 18px;
            border-radius: 15px;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .btn-copy-big { background: rgba(255, 255, 255, 0.1); color: white; border: 1px solid rgba(255, 255, 255, 0.2); }
        .btn-email-big { background: #00d4ff; color: white !important; }
        .btn-whatsapp-big { background: #25D366; color: white !important; }
        .btn-back-home { background: transparent; color: #9657f6; border: 1px solid #9657f6; margin-top: 10px; }
        .big-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.3); filter: brightness(1.1); }
        
        .copy-toast {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: #44D8BD;
            color: #05050f;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 700;
            z-index: 100002;
            opacity: 0;
            transition: opacity 0.3s;
            pointer-events: none;
        }
        .copy-toast.show { opacity: 1; }

        @media (max-width: 600px) {
            .action-row { grid-template-columns: 1fr; }
            .brief-container { padding: 25px; margin: 20px auto; }
            .brief-header h2 { font-size: 1.5rem; }
        }

        html, body {
            background: #05050f;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow-x: hidden;
            font-family: 'Poppins', sans-serif;
        }
        #loadingScreen {
            display: none !important;
        }
        .loading-screen.fade-out {
            animation: loaderFadeOut 0.8s ease forwards;
        }
        @keyframes loaderFadeOut {
            0% { opacity: 1; }
            100% { opacity: 0; visibility: hidden; pointer-events: none; }
        }
        .loader-bg-particles {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        .loader-particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: linear-gradient(135deg, #00d4ff, #9657f6);
            border-radius: 50%;
            animation: loaderParticleFloat 8s infinite ease-in-out;
        }
        .loader-particle:nth-child(1) { top: 10%; left: 10%; animation-delay: 0s; }
        .loader-particle:nth-child(2) { top: 20%; left: 80%; animation-delay: 1s; }
        .loader-particle:nth-child(3) { top: 60%; left: 15%; animation-delay: 2s; }
        .loader-particle:nth-child(4) { top: 80%; left: 70%; animation-delay: 0.5s; }
        .loader-particle:nth-child(5) { top: 40%; left: 90%; animation-delay: 1.5s; }
        .loader-particle:nth-child(6) { top: 70%; left: 40%; animation-delay: 2.5s; }
        .loader-particle:nth-child(7) { top: 30%; left: 50%; animation-delay: 0.8s; }
        .loader-particle:nth-child(8) { top: 90%; left: 20%; animation-delay: 1.8s; }
        @keyframes loaderParticleFloat {
            0%, 100% { transform: translateY(0) translateX(0) scale(1); opacity: 0.3; }
            50% { transform: translateY(-100px) translateX(30px) scale(2); opacity: 1; }
        }
        .loader-glow-orb {
            position: absolute;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(0, 212, 255, 0.15) 0%, rgba(150, 87, 246, 0.1) 40%, transparent 70%);
            border-radius: 50%;
            animation: orbPulse 4s infinite ease-in-out;
        }
        @keyframes orbPulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.2); opacity: 0.8; }
        }
        .loader-main {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader-ring {
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            border: 2px solid transparent;
            border-top: 2px solid #00d4ff;
            border-right: 2px solid #9657f6;
            animation: loaderRingSpin 2s linear infinite;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader-ring-inner {
            position: absolute;
            top: 10px;
            left: 10px;
            right: 10px;
            bottom: 10px;
            border-radius: 50%;
            border: 2px solid transparent;
            border-bottom: 2px solid #ff6b6b;
            border-left: 2px solid #44d8bd;
            animation: loaderRingSpinReverse 1.5s linear infinite;
        }
        @keyframes loaderRingSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        @keyframes loaderRingSpinReverse {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(-360deg); }
        }
        .loader-brand {
            display: flex;
            gap: 4px;
            z-index: 10;
        }
        .loader-letter {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #00d4ff 0%, #9657f6 50%, #ff6b6b 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: loaderLetterReveal 0.6s ease forwards;
            animation-delay: calc(var(--i) * 0.1s);
            opacity: 0;
            transform: translateY(30px);
        }
        @keyframes loaderLetterReveal {
            0% { opacity: 0; transform: translateY(30px) scale(0.5); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        .loader-tagline {
            margin-top: 80px;
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.6);
            letter-spacing: 4px;
            text-transform: uppercase;
            animation: loaderTaglineFade 1s ease forwards;
            animation-delay: 1s;
            opacity: 0;
        }
        @keyframes loaderTaglineFade {
            0% { opacity: 0; transform: translateY(10px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .loader-progress {
            position: absolute;
            bottom: 80px;
            width: 200px;
            height: 3px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        .loader-progress-bar {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #00d4ff, #9657f6, #ff6b6b);
            border-radius: 10px;
            animation: loaderProgress 2s ease forwards;
        }
        @keyframes loaderProgress {
            0% { width: 0%; }
            100% { width: 100%; }
        }
        .step-progress {
            max-width: 800px;
            margin: 0 auto 60px;
            width: 100%;
            display: flex;
            justify-content: space-between;
            position: relative;
        }
        .step-progress::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 0;
            right: 0;
            height: 2px;
            background: rgba(255,255,255,0.1);
            z-index: 1;
        }
        .progress-bar {
            position: absolute;
            top: 15px;
            left: 0;
            height: 2px;
            background: #9657f6;
            z-index: 2;
            transition: width 0.4s ease;
        }
        .progress-step {
            width: 32px;
            height: 32px;
            background: #1a1a2e;
            border: 2px solid rgba(255,255,255,0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 3;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .progress-step.active {
            border-color: #9657f6;
            background: #9657f6;
            box-shadow: 0 0 15px rgba(150, 87, 246, 0.5);
        }
        .step-content {
            max-width: 800px;
            margin: 0 auto;
            width: 100%;
            flex-grow: 1;
        }
        .step-panel {
            display: none;
            animation: slideIn 0.4s ease-out;
        }
        .step-panel.active { display: block; }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(30px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .step-title { font-size: 2.2rem; margin-bottom: 8px; font-weight: 700; }
        .step-desc { color: #a0a0c0; margin-bottom: 35px; font-size: 1rem; }
        
        .option-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .option-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        .option-card i { font-size: 1.8rem; margin-bottom: 12px; color: #9657f6; }
        .option-card:hover { border-color: #9657f6; background: rgba(150, 87, 246, 0.05); transform: translateY(-5px); }
        .option-card.selected { border-color: #9657f6; background: #9657f6; }
        .option-card.selected i { color: white; }
        .option-card.selected div { color: white; }
        .option-card div { font-size: 0.95rem; color: #e0e0e0; }
        
        .nav-btns {
            display: flex;
            justify-content: space-between;
            margin-top: auto;
            padding-top: 40px;
        }
        .btn-nav {
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            font-size: 0.95rem;
        }
        .btn-prev { background: rgba(255,255,255,0.05); color: white; }
        .btn-next { background: #9657f6; color: white; }
        .btn-nav:disabled { opacity: 0.5; cursor: not-allowed; }

        .input-group { margin-bottom: 25px; }
        .input-group label { display: block; margin-bottom: 8px; color: #a0a0c0; font-size: 0.9rem; }
        .fancy-input {
            width: 100%;
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.1);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 1rem;
        }
        .fancy-input:focus { border-color: #9657f6; outline: none; }
    </style>
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Innovation in Action</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <img src="assets/images/logo.svg" alt="UnityDev Logo" onerror="this.style.display='none'">
                    <h2>UNITYDEV</h2>
                </div>
                <div class="nav-menu" id="navMenu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="blog.php">Blog</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="index.php#contact">Contact</a></li>
                    </ul>
                    <div class="nav-buttons">
                        <a href="resume.php" class="btn-outline">Resume</a>
                        <a href="hire.php" class="btn-primary">Hire Me</a>
                    </div>
                </div>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <div class="brief-page-overlay" id="briefPage">
        <div class="brief-container">
            <div class="brief-header">
                <i class="fas fa-file-contract"></i>
                <div>
                    <h2>Project Brief</h2>
                    <p style="color: #a0a0c0; margin: 0;">Finalized Requirements</p>
                </div>
            </div>

            <div class="brief-display" id="briefDisplayText"></div>

            <div class="brief-footer-actions">
                <button type="button" class="big-btn btn-copy-big" onclick="copyBrief()">
                    <i class="fas fa-copy"></i> COPY TO CLIPBOARD
                </button>
                
                <div class="action-row">
                    <button type="button" class="big-btn btn-email-big" onclick="sendEmail()">
                        <i class="fas fa-envelope"></i> SEND TO EMAIL
                    </button>
                    <button type="button" class="big-btn btn-whatsapp-big" onclick="sendWhatsApp()">
                        <i class="fab fa-whatsapp"></i> WHATSAPP
                    </button>
                </div>

                <a href="index.php" class="big-btn btn-back-home">
                    RETURN TO HOME
                </a>
            </div>
        </div>
    </div>

    <div class="copy-toast" id="copyToast">COPIED TO CLIPBOARD!</div>

    <div class="notification-overlay" id="projectNotify">
        <div class="notification-flyer">
            <div class="flyer-scanner"></div>
            <div class="flyer-bg-drawing">
                <svg viewBox="0 0 100 100">
                    <path class="drawing-path" d="M10 10 L90 10 L90 90 L10 90 Z" fill="none" stroke="rgba(150, 87, 246, 0.2)" stroke-width="0.5" />
                    <circle cx="50" cy="50" r="30" fill="none" stroke="rgba(150, 87, 246, 0.1)" stroke-width="0.5" />
                </svg>
            </div>
            <div class="flyer-illustration-container">
                <div class="illustration-orbit">
                    <div class="orbit-dot"></div>
                </div>
                <div class="illustration-main">
                    <i class="fas fa-rocket" style="font-size: 3rem; color: #9657f6;"></i>
                </div>
            </div>
            <h3 class="flyer-title" id="flyerTitle">Project Builder</h3>
            
            <div id="welcomeContent">
                <p class="flyer-text">Ready to bring your vision to life? Complete these steps to define your project requirements. Once finished, we'll generate a professional project brief for you.</p>
                <button class="flyer-btn" onclick="closeNotify()">
                    <span class="btn-shine"></span>
                    LET'S START!
                </button>
            </div>
        </div>
    </div>

    <div class="step-page">
        <div class="container" style="max-width: 800px; margin: 0 auto 10px;">
            <a href="hire.php" style="color: #9657f6; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: 600; margin-bottom: 20px;">
                <i class="fas fa-arrow-left"></i> Back to Hire Options
            </a>
        </div>
        <div class="step-progress">
            <div class="progress-bar" id="progressBar" style="width: 0%"></div>
            <div class="progress-step active" data-step="1">1</div>
            <div class="progress-step" data-step="2">2</div>
            <div class="progress-step" data-step="3">3</div>
            <div class="progress-step" data-step="4">4</div>
            <div class="progress-step" data-step="5">5</div>
            <div class="progress-step" data-step="6">6</div>
        </div>

        <div class="step-content">
            <!-- Step 1: Platform -->
            <div class="step-panel active" id="step1">
                <h2 class="step-title">What are you looking to build?</h2>
                <p class="step-desc">Select the platform that fits your project best.</p>
                <div class="option-grid">
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Website')"><i class="fas fa-globe"></i><div>Website</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Mobile App')"><i class="fas fa-mobile-alt"></i><div>Mobile App</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Desktop App')"><i class="fas fa-desktop"></i><div>Desktop App</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'E-commerce')"><i class="fas fa-shopping-cart"></i><div>E-commerce</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'SaaS')"><i class="fas fa-cloud"></i><div>SaaS Platform</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Portfolio')"><i class="fas fa-user-tie"></i><div>Portfolio</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Blog')"><i class="fas fa-blog"></i><div>Blog</div></div>
                    <div class="option-card" onclick="selectOption(this, 'platform', 'Admin Panel')"><i class="fas fa-user-shield"></i><div>Admin Panel</div></div>
                </div>
                <div class="input-group">
                    <label>Other platform type</label>
                    <input type="text" class="fancy-input" id="platformOther" placeholder="Type here...">
                </div>
            </div>

            <!-- Step 2: Design -->
            <div class="step-panel" id="step2">
                <h2 class="step-title">Choose a design style</h2>
                <p class="step-desc">Help me understand the visual vibe you're going for.</p>
                <div class="option-grid">
                    <div class="option-card" onclick="selectOption(this, 'design', 'Minimalist')"><i class="fas fa-leaf"></i><div>Minimalist</div></div>
                    <div class="option-card" onclick="selectOption(this, 'design', 'Modern')"><i class="fas fa-bolt"></i><div>Modern</div></div>
                    <div class="option-card" onclick="selectOption(this, 'design', 'Classic')"><i class="fas fa-landmark"></i><div>Classic</div></div>
                    <div class="option-card" onclick="selectOption(this, 'design', 'Colorful')"><i class="fas fa-palette"></i><div>Colorful</div></div>
                    <div class="option-card" onclick="selectOption(this, 'design', 'Futuristic')"><i class="fas fa-rocket"></i><div>Futuristic</div></div>
                    <div class="option-card" onclick="selectOption(this, 'design', 'Professional')"><i class="fas fa-briefcase"></i><div>Professional</div></div>
                </div>
                <div class="input-group">
                    <label>Other design preference</label>
                    <input type="text" class="fancy-input" id="designOther" placeholder="Type here...">
                </div>
            </div>

            <!-- Step 3: Colors -->
            <div class="step-panel" id="step3">
                <h2 class="step-title">Brand Colors</h2>
                <p class="step-desc">Do you have specific colors in mind?</p>
                <div class="option-grid">
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Blue')"><div style="width:20px;height:20px;background:#3498db;margin:0 auto 10px;border-radius:4px;"></div><div>Blue</div></div>
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Red')"><div style="width:20px;height:20px;background:#e74c3c;margin:0 auto 10px;border-radius:4px;"></div><div>Red</div></div>
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Green')"><div style="width:20px;height:20px;background:#2ecc71;margin:0 auto 10px;border-radius:4px;"></div><div>Green</div></div>
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Purple')"><div style="width:20px;height:20px;background:#9b59b6;margin:0 auto 10px;border-radius:4px;"></div><div>Purple</div></div>
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Dark Mode')"><div style="width:20px;height:20px;background:#2c3e50;margin:0 auto 10px;border-radius:4px;"></div><div>Dark Mode</div></div>
                    <div class="option-card" onclick="selectOption(this, 'colors', 'Light Mode')"><div style="width:20px;height:20px;background:#ecf0f1;margin:0 auto 10px;border-radius:4px;border:1px solid #ccc;"></div><div>Light Mode</div></div>
                </div>
                <div class="input-group">
                    <label>Custom Hex Codes or Names</label>
                    <input type="text" class="fancy-input" id="colorsOther" placeholder="e.g. #ff5500, Gold">
                </div>
            </div>

            <!-- Step 4: Database -->
            <div class="step-panel" id="step4">
                <h2 class="step-title">Technical Requirements</h2>
                <p class="step-desc">Which database or backend technology do you prefer?</p>
                <div class="option-grid">
                    <div class="option-card" onclick="selectOption(this, 'db', 'Firebase')"><i class="fas fa-fire"></i><div>Firebase</div></div>
                    <div class="option-card" onclick="selectOption(this, 'db', 'MongoDB')"><i class="fas fa-leaf"></i><div>MongoDB</div></div>
                    <div class="option-card" onclick="selectOption(this, 'db', 'MySQL')"><i class="fas fa-database"></i><div>MySQL</div></div>
                    <div class="option-card" onclick="selectOption(this, 'db', 'PostgreSQL')"><i class="fas fa-server"></i><div>PostgreSQL</div></div>
                    <div class="option-card" onclick="selectOption(this, 'db', 'SQLite')"><i class="fas fa-file-code"></i><div>SQLite</div></div>
                    <div class="option-card" onclick="selectOption(this, 'db', 'Redis')"><i class="fas fa-bolt"></i><div>Redis</div></div>
                </div>
                <div class="input-group">
                    <label>Other database</label>
                    <input type="text" class="fancy-input" id="dbOther" placeholder="Type here...">
                </div>
            </div>

            <!-- Step 5: Pages -->
            <div class="step-panel" id="step5">
                <h2 class="step-title">Project Scale</h2>
                <p class="step-desc">How many pages/screens does your project need?</p>
                <div class="option-grid">
                    <div class="option-card" onclick="selectOption(this, 'pages', '1-5')"><i class="fas fa-file"></i><div>1-5 Pages</div></div>
                    <div class="option-card" onclick="selectOption(this, 'pages', '6-10')"><i class="fas fa-copy"></i><div>6-10 Pages</div></div>
                    <div class="option-card" onclick="selectOption(this, 'pages', '11-20')"><i class="fas fa-layer-group"></i><div>11-20 Pages</div></div>
                    <div class="option-card" onclick="selectOption(this, 'pages', '20-50')"><i class="fas fa-cubes"></i><div>20-50 Pages</div></div>
                    <div class="option-card" onclick="selectOption(this, 'pages', '50+')"><i class="fas fa-network-wired"></i><div>50+ Pages</div></div>
                </div>
            </div>

            <!-- Step 6: Notes -->
            <div class="step-panel" id="step6">
                <h2 class="step-title">Final Details</h2>
                <p class="step-desc">Anything else I should know before we start?</p>
                <div class="input-group">
                    <label>Additional Notes</label>
                    <textarea class="fancy-input" id="notes" rows="6" placeholder="Describe your project goals, features..."></textarea>
                </div>
            </div>

            <div class="nav-btns">
                <button class="btn-nav btn-prev" id="prevBtn" onclick="changeStep(-1)" disabled>Back</button>
                <button class="btn-nav btn-next" id="nextBtn" onclick="changeStep(1)">Next Step</button>
            </div>
        </div>
    </div>

    <script>
        let currentStep = 1;
        const selections = {
            platform: '', design: '', colors: '', db: '', pages: ''
        };

        function selectOption(el, category, value) {
            const cards = el.parentElement.querySelectorAll('.option-card');
            cards.forEach(c => c.classList.remove('selected'));
            el.classList.add('selected');
            selections[category] = value;
        }

        function changeStep(delta) {
            if (delta === 1) {
                const currentPanel = document.getElementById(`step${currentStep}`);
                const hasSelection = currentPanel.querySelector('.selected');
                const hasInput = currentPanel.querySelector('.fancy-input') && currentPanel.querySelector('.fancy-input').value.trim() !== '';
                
                // Step 6 is the notes section, it's optional so we allow next
                if (currentStep < 6 && !hasSelection && !hasInput) {
                    alert('Please select an option or type in your preference to continue.');
                    return;
                }
            }

            const next = currentStep + delta;
            if (next < 1 || next > 6) return;

            if (next === 6) {
                document.getElementById('nextBtn').innerText = 'Generate Brief';
                // Attach the click handler directly to ensure it works
                document.getElementById('nextBtn').onclick = function() {
                    if (currentStep === 6) {
                        submitForm();
                    } else {
                        changeStep(1);
                    }
                };
            } else {
                document.getElementById('nextBtn').innerText = 'Next Step';
                document.getElementById('nextBtn').onclick = function() { changeStep(1); };
            }

            if (currentStep === 6 && delta === 1) {
                submitForm();
                return;
            }

            document.getElementById(`step${currentStep}`).classList.remove('active');
            document.getElementById(`step${next}`).classList.add('active');
            
            currentStep = next;
            updateProgress();
        }

        function updateProgress() {
            document.getElementById('progressBar').style.width = ((currentStep - 1) / 5) * 100 + '%';
            document.querySelectorAll('.progress-step').forEach((s, idx) => {
                if (idx < currentStep) s.classList.add('active');
                else s.classList.remove('active');
            });
            document.getElementById('prevBtn').disabled = currentStep === 1;
        }

        function closeNotify() {
            const overlay = document.getElementById('projectNotify');
            overlay.classList.remove('active');
            setTimeout(() => {
                overlay.style.display = 'none';
            }, 800);
        }

        // Add to bottom of script
        window.addEventListener('DOMContentLoaded', function() {
            // Remove dependencies on images that might 404
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                img.onerror = function() { this.style.display = 'none'; };
                if (img.complete && img.naturalHeight === 0) {
                    img.style.display = 'none';
                }
            });

            // FORCE REMOVE LOADING SCREEN IMMEDIATELY
            const loadingScreen = document.getElementById('loadingScreen');
            if (loadingScreen) {
                loadingScreen.parentNode.removeChild(loadingScreen);
            }
            
            const overlay = document.getElementById('projectNotify');
            if (overlay) {
                overlay.style.display = 'flex';
                setTimeout(() => {
                    overlay.classList.add('active');
                }, 50);
            }
        });

        let generatedBrief = "";

        function submitForm() {
            const platformOther = document.getElementById('platformOther').value.trim();
            const platform = (selections.platform && platformOther) 
                ? `${selections.platform} (${platformOther})` 
                : (selections.platform || platformOther || 'Not Specified');

            const designOther = document.getElementById('designOther').value.trim();
            const design = (selections.design && designOther)
                ? `${selections.design} (${designOther})`
                : (selections.design || designOther || 'Not Specified');

            const colorsOther = document.getElementById('colorsOther').value.trim();
            const colors = (selections.colors && colorsOther)
                ? `${selections.colors} (${colorsOther})`
                : (selections.colors || colorsOther || 'Not Specified');

            const dbOther = document.getElementById('dbOther').value.trim();
            const db = (selections.db && dbOther)
                ? `${selections.db} (${dbOther})`
                : (selections.db || dbOther || 'Not Specified');

            const pages = selections.pages || 'Not Specified';
            const notes = document.getElementById('notes').value.trim() || 'No additional notes';

            generatedBrief = `Dear UnityDev Team,\n\n` +
                        `I am writing to inquire about starting a new project. Below are the specific requirements I've outlined using your Project Builder:\n\n` +
                        `PROJECT SPECIFICATIONS:\n` +
                        `--------------------------\n` +
                        `• Platform Type: ${platform}\n` +
                        `• Design Preference: ${design}\n` +
                        `• Brand Colors: ${colors}\n` +
                        `• Tech/Database: ${db}\n` +
                        `• Project Scale: ${pages}\n\n` +
                        `ADDITIONAL CONTEXT:\n` +
                        `${notes}\n\n` +
                        `--------------------------\n` +
                        `Sent via UnityDev Portfolio Builder`;
            
            // Show the Brief Page
            document.getElementById('briefDisplayText').innerText = generatedBrief;
            const briefPage = document.getElementById('briefPage');
            briefPage.style.display = 'block';
            setTimeout(() => briefPage.classList.add('active'), 10);
        }

        function copyBrief() {
            navigator.clipboard.writeText(generatedBrief).then(() => {
                const toast = document.getElementById('copyToast');
                toast.classList.add('show');
                setTimeout(() => toast.classList.remove('show'), 2000);
            });
        }

        function sendEmail() {
            const email = "bestakinyemi203@gmail.com";
            const subject = "New Project Inquiry - UnityDev";
            const mailtoUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${email}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(generatedBrief)}`;
            window.open(mailtoUrl, '_blank');
        }

        function sendWhatsApp() {
            const phone = "61468302435";
            const text = encodeURIComponent(generatedBrief);
            const whatsappUrl = `https://wa.me/${phone}?text=${text}`;
            window.open(whatsappUrl, '_blank');
        }

        // Mobile Menu Toggle
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('navMenu');

        if (hamburger) {
            hamburger.addEventListener('click', () => {
                hamburger.classList.toggle('active');
                navMenu.classList.toggle('active');
            });
        }
    </script>
</body>
</html>
