<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hire Me - UnityDev</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body {
            overflow-x: hidden;
            background: #05050f;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .hire-hero {
            padding: 150px 0 100px;
            background: #05050f;
            text-align: center;
        }
        .hire-hero h1 { font-size: 3.5rem; margin-bottom: 20px; font-weight: 800; color: white; }
        .hire-hero p { color: #a0a0c0; max-width: 600px; margin: 0 auto; font-size: 1.1rem; }

        .choice-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1000px;
            margin: -50px auto 100px;
            padding: 0 20px;
        }
        .choice-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.1);
            padding: 50px 40px;
            border-radius: 30px;
            text-align: center;
            transition: all 0.4s;
            cursor: pointer;
            text-decoration: none;
            color: white;
            display: block;
        }
        .choice-card:hover {
            transform: translateY(-15px);
            border-color: #9657f6;
            background: rgba(150, 87, 246, 0.05);
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
        }
        .choice-card i { font-size: 3.5rem; color: #9657f6; margin-bottom: 25px; display: block; }
        .choice-card h3 { font-size: 1.6rem; margin-bottom: 12px; font-weight: 700; }
        .choice-card p { color: #a0a0c0; font-size: 0.95rem; }
    </style>
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Crafting Digital Excellence</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <a href="index.php" style="text-decoration: none; display: flex; align-items: center; gap: 10px; color: white;">
                        <img src="assets/images/logo.svg" alt="UnityDev Logo">
                        <h2 style="margin: 0;">UNITYDEV</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                    <a href="hire.php" class="btn-primary">Hire Me</a>
                </div>
            </div>
        </div>
    </nav>

    <section class="hire-hero">
        <div class="container">
            <div style="text-align: left; margin-bottom: 30px;">
                <a href="index.php" style="color: #9657f6; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: 600;">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>
            <h1>Start a Project</h1>
            <p>Ready to build something amazing? Choose your preferred way to get started.</p>
        </div>
    </section>

    <div class="choice-grid">
        <a href="start-project.php" class="choice-card">
            <i class="fas fa-rocket"></i>
            <h3>Step-by-Step</h3>
            <p>Follow a simple process to define your project requirements clearly.</p>
        </a>
        <a href="https://wa.me/61468302425" class="choice-card">
            <i class="fab fa-whatsapp"></i>
            <h3>Direct Chat</h3>
            <p>Skip the forms and talk to me directly about your vision right now.</p>
        </a>
    </div>

    <footer class="footer" style="padding: 50px 0; border-top: 1px solid rgba(255,255,255,0.1); background: #05050f;">
        <div class="container" style="text-align: center;">
            <p>&copy; 2026 UnityDev. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
</body>
</html>
