<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me - UnityDev</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Crafting Digital Excellence</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <!-- Mega Premium Notification -->
    <div class="notification-overlay" id="aboutNotify">
        <div class="notification-flyer">
            <div class="flyer-scanner"></div>
            <div class="flyer-bg-drawing">
                <svg viewBox="0 0 400 400">
                    <circle cx="200" cy="200" r="150" stroke="rgba(0,3,255,0.1)" stroke-width="1" fill="none" class="drawing-path" />
                    <path d="M50,200 L350,200 M200,50 L200,350" stroke="rgba(0,3,255,0.05)" fill="none" />
                </svg>
            </div>
            <div class="flyer-illustration-container">
                <div class="illustration-orbit">
                    <div class="orbit-dot"></div>
                </div>
                <div class="illustration-main">
                    <svg viewBox="0 0 100 100" width="100" height="100">
                        <circle cx="50" cy="50" r="35" fill="none" stroke="#44D8BD" stroke-width="3" class="drawing-path" />
                        <path d="M35,50 L45,60 L65,40" fill="none" stroke="#fff" stroke-width="3" />
                    </svg>
                </div>
            </div>
            <h3 class="flyer-title">About Our Vision</h3>
            <p class="flyer-text">Discover the engineering excellence and creative passion that drives UnityDev to redefine digital standards.</p>
            <button class="flyer-btn" onclick="closeNotification('aboutNotify')">
                EXPLORE NOW
                <div class="btn-shine"></div>
            </button>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <img src="assets/images/logo.svg" alt="UnityDev Logo">
                    <h2>UNITYDEV</h2>
                </div>
                <div class="nav-menu" id="navMenu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php" class="active">About</a></li>
                        <li><a href="index.php#contact">Contact</a></li>
                    </ul>
                    <div class="nav-buttons">
                        <a href="resume.php" class="btn-outline">Resume</a>
                        <a href="index.php#contact" class="btn-primary">Hire Me</a>
                    </div>
                </div>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
            <div class="dots-line"></div>
        </div>
        <div class="container">
            <div class="page-header-content">
                <div class="header-animation">
                    <div class="rotating-sphere">
                        <div class="sphere-face front">ABOUT</div>
                        <div class="sphere-face back">ME</div>
                        <div class="sphere-face left">UNITY</div>
                        <div class="sphere-face right">DEV</div>
                    </div>
                </div>
                <div class="header-text">
                    <h1 class="page-title">About Me</h1>
                    <p class="page-subtitle">Get to know more about my journey and expertise</p>
                </div>
            </div>
        </div>
    </section>

    <section class="about-content">
        <div class="container">
            <div class="about-grid">
                <div class="about-image" style="display: flex; justify-content: center; align-items: center;">
                    <div class="team-slideshow" style="width: 100%; max-width: 400px; height: 400px; position: relative; border-radius: 50%; overflow: hidden; border: 3px solid var(--primary-color); box-shadow: 0 0 30px rgba(102, 126, 234, 0.5);">
                        <div class="team-slide">
                            <img src="attached_assets/c564779e-28b1-4e9e-b181-7c636b06735e_1760251381327.jpeg" alt="Team Member 1">
                            <div class="slide-text">Excellence in Every Project</div>
                        </div>
                        <div class="team-slide">
                            <img src="attached_assets/3b4deacf-8560-49bb-80d5-8a521d6b686b_1760251381327.jpeg" alt="Team Member 2">
                            <div class="slide-text">Team - Building Your Vision</div>
                        </div>
                        <div class="team-slide">
                            <img src="attached_assets/6f043149-8eab-4f47-99bc-3f3db64597ae_1760251381327.jpeg" alt="Team Member 3">
                            <div class="slide-text">Dedicated to Your Success</div>
                        </div>
                    </div>
                </div>
                <div class="about-text">
                    <h2>Hi, I'm <span class="brand-name">UnityDev</span></h2>
                    <h3>Full Stack Developer & UI/UX Designer</h3>
                    <p>I'm a passionate full-stack developer with over 2 years of experience building modern, responsive web applications. My journey in web development started with a curiosity about how websites work, and it has evolved into a full-fledged career where I create digital experiences that make a difference.</p>
                    <p>I specialize in creating seamless user experiences combined with robust backend solutions. My approach combines technical expertise with creative problem-solving to deliver projects that not only meet but exceed client expectations.</p>
                    <p>When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, or sharing knowledge with the developer community.</p>
                    <div class="about-stats">
                        <div class="about-stat">
                            <h4>10+</h4>
                            <p>Projects Completed</p>
                        </div>
                        <div class="about-stat">
                            <h4>13+</h4>
                            <p>Happy Clients</p>
                        </div>
                        <div class="about-stat">
                            <h4>12+</h4>
                            <p>Active Projects</p>
                        </div>
                        <div class="about-stat">
                            <h4>2 Years+</h4>
                            <p>Experience</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="skills-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-label">My Expertise</h3>
                <h2 class="section-title">Technical Skills</h2>
            </div>
            <div class="skills-grid">
                <div class="skill-category">
                    <h3><i class="fas fa-laptop-code"></i> Frontend Development</h3>
                    <div class="skill-items">
                        <div class="skill-item">
                            <span>HTML5 / CSS3</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 95%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>JavaScript / TypeScript</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 90%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>React / Vue / Angular</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 88%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Tailwind / Bootstrap</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 92%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="skill-category">
                    <h3><i class="fas fa-server"></i> Backend Development</h3>
                    <div class="skill-items">
                        <div class="skill-item">
                            <span>Node.js / Express</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 85%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Python / Django</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 82%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>PHP / Laravel</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 80%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>RESTful APIs</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 90%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="skill-category">
                    <h3><i class="fas fa-database"></i> Database & Tools</h3>
                    <div class="skill-items">
                        <div class="skill-item">
                            <span>MongoDB / MySQL</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 87%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Firebase</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 92%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>PostgreSQL</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 83%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Git / GitHub</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 92%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Docker / AWS</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 78%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="skill-category">
                    <h3><i class="fas fa-paint-brush"></i> Design & Other</h3>
                    <div class="skill-items">
                        <div class="skill-item">
                            <span>UI/UX Design</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 85%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Figma / Adobe XD</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 80%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>Responsive Design</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 95%"></div>
                            </div>
                        </div>
                        <div class="skill-item">
                            <span>SEO Optimization</span>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 82%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="experience-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-label">My Journey</h3>
                <h2 class="section-title">Work Experience</h2>
            </div>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-date">2022 - Present</div>
                    <div class="timeline-content">
                        <h3>Senior Full Stack Developer</h3>
                        <h4>Freelance / Remote</h4>
                        <p>Leading multiple web development projects, specializing in MERN stack applications. Successfully delivered 30+ projects for clients worldwide.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2020 - 2022</div>
                    <div class="timeline-content">
                        <h3>Full Stack Developer</h3>
                        <h4>Tech Solutions Inc.</h4>
                        <p>Developed and maintained enterprise-level web applications. Worked with cross-functional teams to deliver scalable solutions.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2019 - 2020</div>
                    <div class="timeline-content">
                        <h3>Frontend Developer</h3>
                        <h4>Digital Agency</h4>
                        <p>Created responsive and user-friendly interfaces for various clients. Collaborated with designers to bring mockups to life.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="experience-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-label">My Professional Ethics</h3>
                <h2 class="section-title">Why You Can Trust Me - A Word About Scammers</h2>
            </div>
            <div class="about-text" style="max-width: 1000px; margin: 0 auto;">
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    In today's digital world, trust is everything. I know many of you have been burned by fake developers and scammers who take your money and disappear. I've heard countless stories from clients who lost thousands to people claiming to be developers, only to receive incomplete work or nothing at all. This breaks my heart because it makes genuine professionals like me work twice as hard to prove we're legitimate.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    Let me be clear: I am NOT a scammer. I've built my reputation on honesty, transparency, and delivering real results. Every project in my portfolio represents actual work completed for real clients. I don't make promises I can't keep, and I don't take on projects I'm not qualified to handle. If something is beyond my expertise, I'll tell you upfront and refer you to someone who can help, rather than wasting your time and money.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    My approach to every project is simple: clear communication from day one. Before we start, I provide detailed proposals outlining exactly what you'll get, the timeline, and the cost. No hidden fees, no surprise charges, no excuses. I use milestone-based payment systems where you only pay as work is completed and approved. This protects both of us and ensures you're getting value for your investment.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I understand that for many business owners, hiring a developer feels like a leap of faith. You're trusting someone with your vision, your budget, and sometimes your business's future. That's why I go above and beyond to prove my reliability. I provide regular updates, show you work in progress, and remain available for questions and concerns throughout the project. My clients aren't just transactions, they're partnerships.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I've also learned to spot red flags that indicate someone might be dealing with a scammer. Here's what I advise: legitimate developers will always show you their previous work, provide client references, communicate professionally, and never pressure you into quick decisions. Real professionals understand that good work takes time and proper planning. If someone promises you a complex e-commerce platform in two days for $50, run the other way. Quality development requires expertise, time, and fair compensation.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    My commitment to ethical practices extends beyond just avoiding scams. I believe in empowering my clients with knowledge. I explain technical concepts in simple terms, teach you how to manage your website after completion, and provide documentation so you're never dependent solely on me. A good developer builds solutions that work for you long-term, not systems that keep you trapped and paying indefinitely.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I've worked with clients who came to me after bad experiences with scammers, and I've helped them not just rebuild their projects but restore their faith in the development community. There's nothing more rewarding than seeing a client's stress turn to excitement as they watch their vision finally come to life properly.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    Remember, the cheapest option is rarely the best option. Invest in quality, transparency, and professionalism. When you work with me, you're not just hiring a developer, you're partnering with someone who genuinely cares about your success and has the integrity to deliver on every promise. Your trust is sacred to me, and I protect it with honest work and unwavering dedication.
                </p>
            </div>
        </div>
    </section>

    <section class="skills-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-label">Real Talk</h3>
                <h2 class="section-title">About Life, Struggle, and Success as a Developer</h2>
            </div>
            <div class="about-text" style="max-width: 1000px; margin: 0 auto;">
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    Let me share something real with you: life is not easy, especially in this field. Behind every successful developer you see online, there's a story of countless sleepless nights, failed projects, rejected proposals, and moments of self-doubt. I'm no different. My journey to becoming a full-stack developer wasn't a straight path, it was filled with obstacles that tested my resolve every single day.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I remember when I was just starting, struggling to land my first client. I had the skills, the passion, and the dedication, but no one wanted to take a chance on an unknown developer. I sent hundreds of proposals, created countless sample projects just to prove myself, and worked for far less than I deserved just to build my portfolio. There were times I questioned if I made the right career choice.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    The financial pressure was real. Internationally, as in many parts of the world, opportunities aren't always equal. You can have all the talent in the world, but without the right connections or resources, breaking through feels impossible. I've worked on projects late into the night after spending all day searching for opportunities. I've skipped meals to save money for internet data to learn new technologies. I've faced rejection after rejection, each one stinging more than the last.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    But here's what I learned: struggle builds character and resilience. Every challenge taught me something valuable. Every failed project showed me what not to do. Every difficult client helped me improve my communication skills. Every technical problem I solved made me a better developer. The struggle wasn't meant to break me, it was shaping me into the professional I am today.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I understand that many of my clients are also fighting their own battles. You're entrepreneurs trying to build something from nothing. You're small business owners competing against bigger companies with larger budgets. You're individuals with big dreams but limited resources. I see myself in you, and that's why I approach every project with empathy and understanding. I know what it's like to invest your last funds into something you believe in.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    This is why I'm flexible with payment plans, why I go the extra mile even when it's not in the contract, and why I celebrate your wins like they're my own. Your success is my success. When your website attracts customers, when your app changes your business, when your digital presence finally matches your vision, that's what makes all the struggle worth it.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    For fellow developers reading this, especially those just starting: don't give up. The beginning is always the hardest. Keep learning, keep building, and keep pushing forward. Create projects even when no one's paying you. Contribute to open-source. Help others in developer communities. Build a portfolio that speaks louder than any degree. Your breakthrough will come, trust the process.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    Life will always have ups and downs, but what matters is how we respond. I choose to use my struggles as motivation to help others avoid the same pitfalls. I choose to be the developer I wish I had when I was starting out, someone honest, accessible, and genuinely invested in client success. We're all in this together, fighting to create better futures for ourselves and those we serve.
                </p>
            </div>
        </div>
    </section>

    <section class="experience-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-label">Your Privacy Matters</h3>
                <h2 class="section-title">How I Protect Your Information and Business Data</h2>
            </div>
            <div class="about-text" style="max-width: 1000px; margin: 0 auto;">
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    In an age where data breaches make headlines daily and privacy seems like a luxury, I want to assure you that your information is completely safe with me. Privacy and confidentiality aren't just buzzwords in my practice, they're fundamental principles that guide every aspect of my work. When you trust me with your project, you're also trusting me with sensitive business information, user data, and proprietary ideas. I don't take that responsibility lightly.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    From day one, every client conversation, document, and piece of code is treated with the utmost confidentiality. I never share client information with anyone, period. Your business ideas, user databases, financial data, API keys, and passwords are secured with industry-standard encryption. I use secure file transfer protocols, encrypted communication channels, and protected development environments. Your data never leaves secure servers, and access is restricted solely to what's necessary for project completion.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I've signed non-disclosure agreements (NDAs) with multiple clients and always welcome them when requested. These legal protections give you peace of mind, but beyond legal obligations, I have a moral commitment to protecting your information. I've worked on projects ranging from healthcare applications handling sensitive patient data to fintech platforms managing financial transactions. Each requires the highest level of security and discretion, and I've never had a single breach or leak.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    When it comes to user data in applications I build, I implement privacy by design. This means building systems where data collection is minimized, user consent is properly obtained, and information is stored securely with appropriate access controls. I follow GDPR principles even for non-European clients because privacy should be a universal right, not dependent on geography. Your users' data is treated with the same care as your business information.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I'll be honest with you: I've been approached by people offering money for client information, asking me to replicate someone's system for a competitor, or wanting me to share proprietary code. Every single time, I've refused without hesitation. My reputation and integrity are worth more than any amount of money. The trust you place in me is sacred, and I would never betray that for short-term gain.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    After project completion, I maintain confidentiality indefinitely. Client code is stored securely for support purposes only and deleted upon request. I don't showcase projects in my portfolio without explicit permission, and even then, I only show what you're comfortable sharing. Some of my best work isn't publicly visible because clients prefer privacy, and I respect that completely.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    My development practice includes regular security audits, staying updated on the latest security vulnerabilities, and implementing best practices for data protection. I use environment variables for sensitive credentials, never hardcode API keys, implement proper authentication and authorization, and ensure all data transmissions are encrypted. Your security is built into every line of code I write.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    I also educate my clients about privacy and security. I'll advise you on best practices for password management, explain why certain security measures are necessary, and help you understand how to protect your business data even after the project is complete. Knowledge is power, and I want you empowered to maintain the security we build together.
                </p>
                <p style="color: var(--text-secondary); line-height: 2; font-size: 1.05rem; margin-bottom: 1.5rem;">
                    Ultimately, privacy protection is about respect. Respect for your business, respect for your users, and respect for the trust you've placed in me. In a world where data is often treated as a commodity, I treat it as the valuable, sensitive asset it truly is. When you work with me, you can sleep peacefully knowing your information is in safe, ethical, and professional hands.
                </p>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Let's Build Something Amazing Together</h2>
                <p>Have a project in mind? I'd love to hear about it and discuss how we can work together.</p>
                <div class="cta-buttons">
                    <a href="index.php#contact" class="btn-primary">Get In Touch</a>
                    <a href="projects.php" class="btn-outline">View Projects</a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>UNITYDEV</h3>
                    <p>Full Stack Developer specializing in modern web applications and user-friendly designs.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="https://wa.me/61468302435"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
                <div class="footer-contact">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-envelope"></i> Odigieunity81@gmail.com</li>
                        <li><i class="fas fa-envelope"></i> bestakinyemi203@gmail.com</li>
                        <li><a href="https://wa.me/61468302435" style="color: inherit; text-decoration: none;"><i class="fas fa-phone"></i> +61 468 302 435</a></li>
                        <li><i class="fas fa-map-marker-alt"></i> California, United States</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 UnityDev. All Rights Reserved.</p>
                <button class="back-to-top" id="backToTop">
                    <i class="fas fa-arrow-up"></i>
                </button>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp Button -->
    <a href="https://wa.me/61468302435" class="whatsapp-float" target="_blank" aria-label="Contact us on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="assets/js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                showNotification('aboutNotify');
            }, 2000);
        });
    </script>
</body>
</html>
