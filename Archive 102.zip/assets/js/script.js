// Notification System
function showNotification(id, delay = 1000) {
    const overlay = document.getElementById(id);
    if (!overlay) return;
    
    setTimeout(() => {
        overlay.classList.add('active');
    }, delay);
}

function closeNotification(id, nextId = null) {
    const overlay = document.getElementById(id);
    if (overlay) {
        overlay.classList.remove('active');
        if (nextId) {
            showNotification(nextId, 300);
        }
    }
}

// Premium Loading Screen
window.addEventListener('load', function() {
    const loadingScreen = document.getElementById('loadingScreen');
    
    if (loadingScreen) {
        setTimeout(() => {
            loadingScreen.classList.add('fade-out');
            setTimeout(() => {
                loadingScreen.style.display = 'none';
                
                // Trigger page-specific notifications
                const page = window.location.pathname.split('/').pop() || 'index.php';
                if (page === 'index.php') {
                    showNotification('welcomeNotify');
                } else if (page === 'projects.php') {
                    showNotification('projectsNotify');
                } else if (page === 'blog.php') {
                    showNotification('blogNotify');
                } else if (page === 'see.php') {
                    showNotification('buildNotify');
                }
            }, 800);
        }, 2200);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const navbar = document.getElementById('navbar');
    const backToTop = document.getElementById('backToTop');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    document.querySelectorAll('.nav-links a, .nav-buttons a').forEach(link => {
        link.addEventListener('click', function() {
            if (navMenu) navMenu.classList.remove('active');
            if (hamburger) hamburger.classList.remove('active');
        });
    });

    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            if (navbar) navbar.classList.add('scrolled');
            if (backToTop) backToTop.classList.add('show');
        } else {
            if (navbar) navbar.classList.remove('scrolled');
            if (backToTop) backToTop.classList.remove('show');
        }
    });

    if (backToTop) {
        backToTop.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    const teamSlideshow = document.querySelector('.team-slideshow');
    if (teamSlideshow) {
        const teamSlides = document.querySelectorAll('.team-slide');
        let currentTeamSlide = 0;
        let teamSlideInterval;
        let slideDirection = 'right'; // Alternating direction

        function goToTeamSlide(n) {
            // Remove active from current slide and add exit animation
            teamSlides[currentTeamSlide].classList.remove('active');
            if (slideDirection === 'right') {
                teamSlides[currentTeamSlide].classList.add('slide-left');
            } else {
                teamSlides[currentTeamSlide].classList.add('slide-right');
            }

            currentTeamSlide = n;
            if (currentTeamSlide >= teamSlides.length) currentTeamSlide = 0;
            if (currentTeamSlide < 0) currentTeamSlide = teamSlides.length - 1;

            // Set up next slide to enter from opposite direction
            teamSlides.forEach((slide, index) => {
                if (index !== currentTeamSlide) {
                    slide.classList.remove('active', 'slide-left', 'slide-right');
                }
            });

            // Enter new slide from the current direction
            if (slideDirection === 'right') {
                teamSlides[currentTeamSlide].classList.remove('slide-left');
                teamSlides[currentTeamSlide].classList.add('slide-right');
            } else {
                teamSlides[currentTeamSlide].classList.remove('slide-right');
                teamSlides[currentTeamSlide].classList.add('slide-left');
            }

            setTimeout(() => {
                teamSlides[currentTeamSlide].classList.add('active');
                teamSlides[currentTeamSlide].classList.remove('slide-left', 'slide-right');
            }, 50);

            // Alternate direction for next slide
            slideDirection = slideDirection === 'right' ? 'left' : 'right';
        }

        function nextTeamSlide() {
            goToTeamSlide(currentTeamSlide + 1);
        }

        function startTeamSlideshow() {
            teamSlideInterval = setInterval(nextTeamSlide, 3000);
        }

        teamSlides[0].classList.add('active');
        startTeamSlideshow();
    }

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', function() {
            const isActive = item.classList.contains('active');
            
            faqItems.forEach(faq => {
                faq.classList.remove('active');
            });
            
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });

    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    const animateElements = document.querySelectorAll('.service-card, .step-item, .feature-item, .testimonial-card');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });

    const statNumbers = document.querySelectorAll('.stat-number');
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalValue = parseInt(target.getAttribute('data-target'));
                animateCounter(target, finalValue);
                statsObserver.unobserve(target);
            }
        });
    }, observerOptions);

    statNumbers.forEach(stat => {
        statsObserver.observe(stat);
    });

    function animateCounter(element, target) {
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                element.textContent = target + (target >= 1000 ? 'k' : '');
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current);
            }
        }, 30);
    }

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            
            alert('Thank you for your message! I will get back to you soon.');
            contactForm.reset();
        });
    }

    const navLinks = document.querySelectorAll('.nav-links a, .nav-buttons a');
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage || (currentPage === '' && linkHref === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    const showcaseTitle = document.getElementById('showcaseTitle');
    if (showcaseTitle) {
        showcaseTitle.textContent = 'Innovation in Action';
    }

    const showcaseVideo = document.getElementById('showcaseVideo');
    if (showcaseVideo) {
        const videos = [
            'https://videos.pexels.com/video-files/2278095/2278095-hd_1920_1080_30fps.mp4',
            'https://videos.pexels.com/video-files/854053/854053-hd_1920_1080_25fps.mp4',
            'https://videos.pexels.com/video-files/854322/854322-hd_1280_720_25fps.mp4',
            'https://videos.pexels.com/video-files/2516162/2516162-hd_1920_1080_24fps.mp4',
            'https://videos.pexels.com/video-files/852292/852292-hd_1728_1080_25fps.mp4'
        ];
        
        const videoTexts = [
            'Building Amazing Digital Experiences',
            'Coding Your Future',
            'Data Security & Encryption',
            'Full Stack Development',
            'Advanced Programming Solutions'
        ];
        
        let currentVideoIndex = 0;
        const videoTextElement = document.querySelector('.video-text');
        
        function changeVideo() {
            currentVideoIndex = (currentVideoIndex + 1) % videos.length;
            showcaseVideo.src = videos[currentVideoIndex];
            if (videoTextElement) {
                videoTextElement.textContent = videoTexts[currentVideoIndex];
            }
            showcaseVideo.play();
        }
        
        showcaseVideo.src = videos[0];
        showcaseVideo.load();
        showcaseVideo.play();
        
        setInterval(changeVideo, 10000);
        
        showcaseVideo.addEventListener('ended', changeVideo);
    }

    const servicesSlideshow = document.querySelector('.services-slideshow');
    if (servicesSlideshow) {
        const slides = document.querySelectorAll('.service-slide');
        const dotsContainer = document.querySelector('.slideshow-dots');
        let currentSlide = 0;
        let slideInterval;

        slides.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.classList.add('dot');
            if (index === 0) dot.classList.add('active');
            dot.addEventListener('click', () => goToSlide(index));
            dotsContainer.appendChild(dot);
        });

        const dots = document.querySelectorAll('.dot');

        function goToSlide(n) {
            slides[currentSlide].classList.remove('active');
            slides[currentSlide].classList.add('prev');
            dots[currentSlide].classList.remove('active');

            currentSlide = n;
            if (currentSlide >= slides.length) currentSlide = 0;
            if (currentSlide < 0) currentSlide = slides.length - 1;

            slides.forEach((slide, index) => {
                if (index !== currentSlide) {
                    slide.classList.remove('active', 'prev');
                }
            });

            slides[currentSlide].classList.add('active');
            slides[currentSlide].classList.remove('prev');
            dots[currentSlide].classList.add('active');
        }

        function nextSlide() {
            goToSlide(currentSlide + 1);
        }

        function startSlideshow() {
            slideInterval = setInterval(nextSlide, 3500);
        }

        function stopSlideshow() {
            clearInterval(slideInterval);
        }

        startSlideshow();

        servicesSlideshow.addEventListener('mouseenter', stopSlideshow);
        servicesSlideshow.addEventListener('mouseleave', startSlideshow);
    }

    const reviewModal = document.getElementById('reviewModal');
    const addReviewBtn = document.getElementById('addReviewBtn');
    const closeModal = document.querySelector('.close-modal');
    const reviewForm = document.getElementById('reviewForm');

    if (addReviewBtn) {
        addReviewBtn.addEventListener('click', function() {
            reviewModal.classList.add('active');
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', function() {
            reviewModal.classList.remove('active');
        });
    }

    window.addEventListener('click', function(e) {
        if (e.target === reviewModal) {
            reviewModal.classList.remove('active');
        }
    });

    // Handle review form submission
    if (reviewForm) {
        reviewForm.addEventListener('submit', function(e) {
            // Form will submit naturally to submit_review.php
            // No need to prevent default or handle with JavaScript
        });
    }
    
    // REVIEWS SLIDER
    const reviewCards = document.querySelectorAll('.premium-review-card');
    const reviewDots = document.querySelectorAll('.review-dot');
    const prevReviewBtn = document.querySelector('.prev-review');
    const nextReviewBtn = document.querySelector('.next-review');
    
    if (reviewCards.length > 0 && reviewDots.length > 0) {
        let currentReviewIndex = 0;
        let reviewInterval;
        
        function showReview(index) {
            reviewCards.forEach((card, i) => {
                card.classList.remove('active-slide');
                if (i === index) {
                    card.classList.add('active-slide');
                }
            });
            reviewDots.forEach((dot, i) => {
                dot.classList.remove('active');
                if (i === index) {
                    dot.classList.add('active');
                }
            });
            currentReviewIndex = index;
        }
        
        function nextReview() {
            let next = currentReviewIndex + 1;
            if (next >= reviewCards.length) next = 0;
            showReview(next);
        }
        
        function prevReview() {
            let prev = currentReviewIndex - 1;
            if (prev < 0) prev = reviewCards.length - 1;
            showReview(prev);
        }
        
        function startReviewSlider() {
            reviewInterval = setInterval(nextReview, 5000);
        }
        
        function stopReviewSlider() {
            clearInterval(reviewInterval);
        }
        
        if (nextReviewBtn) {
            nextReviewBtn.addEventListener('click', function() {
                stopReviewSlider();
                nextReview();
                startReviewSlider();
            });
        }
        
        if (prevReviewBtn) {
            prevReviewBtn.addEventListener('click', function() {
                stopReviewSlider();
                prevReview();
                startReviewSlider();
            });
        }
        
        reviewDots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopReviewSlider();
                showReview(index);
                startReviewSlider();
            });
        });
        
        startReviewSlider();
    }

    // TERMINAL TYPING ANIMATION
    const terminalTyping = document.getElementById('terminalTyping');
    const terminalOutput = document.getElementById('terminalOutput');
    
    if (terminalTyping && terminalOutput) {
        const commands = [
            { cmd: 'npm run build', output: '✓ Build completed successfully in 2.3s' },
            { cmd: 'git push origin main', output: '✓ Changes pushed to remote repository' },
            { cmd: 'docker deploy --prod', output: '✓ Application deployed to production' },
            { cmd: 'node server.js', output: '✓ Server running on port 3000' },
            { cmd: 'php artisan serve', output: '✓ Laravel development server started' }
        ];
        
        let cmdIndex = 0;
        let charIndex = 0;
        
        function typeCommand() {
            const currentCmd = commands[cmdIndex];
            
            if (charIndex < currentCmd.cmd.length) {
                terminalTyping.textContent += currentCmd.cmd[charIndex];
                charIndex++;
                setTimeout(typeCommand, 80);
            } else {
                setTimeout(() => {
                    terminalOutput.innerHTML = '<span style="color: #27ca3f;">' + currentCmd.output + '</span>';
                    setTimeout(() => {
                        terminalTyping.textContent = '';
                        terminalOutput.innerHTML = '';
                        charIndex = 0;
                        cmdIndex = (cmdIndex + 1) % commands.length;
                        setTimeout(typeCommand, 500);
                    }, 2000);
                }, 500);
            }
        }
        
        setTimeout(typeCommand, 1000);
    }

    // CURSOR GLOW EFFECT
    const cursorGlow = document.createElement('div');
    cursorGlow.classList.add('cursor-glow');
    document.body.appendChild(cursorGlow);
    
    document.addEventListener('mousemove', (e) => {
        cursorGlow.style.left = e.clientX + 'px';
        cursorGlow.style.top = e.clientY + 'px';
    });

    // 3D TILT EFFECT ON SERVICE CARDS
    const tiltCards = document.querySelectorAll('.service-card-new');
    
    tiltCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = (y - centerY) / 15;
            const rotateY = (centerX - x) / 15;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-15px) scale(1.02)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0) scale(1)';
        });
    });

    // MANUAL SERVICES CAROUSEL
    const servicesCarousel = document.getElementById('servicesCarousel');
    const prevBtn = document.getElementById('prevService');
    const nextBtn = document.getElementById('nextService');
    const carouselDotsContainer = document.getElementById('carouselDots');
    
    if (servicesCarousel && prevBtn && nextBtn && carouselDotsContainer) {
        const cards = servicesCarousel.querySelectorAll('.service-card-new');
        const cardWidth = 340;
        let currentIndex = 0;
        
        for (let i = 0; i < cards.length; i++) {
            const dot = document.createElement('div');
            dot.classList.add('carousel-dot');
            if (i === 0) dot.classList.add('active');
            dot.addEventListener('click', () => scrollToCard(i));
            carouselDotsContainer.appendChild(dot);
        }
        
        const dots = carouselDotsContainer.querySelectorAll('.carousel-dot');
        
        function updateDots() {
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === currentIndex);
            });
        }
        
        function scrollToCard(index) {
            currentIndex = Math.max(0, Math.min(index, cards.length - 1));
            servicesCarousel.scrollTo({
                left: currentIndex * cardWidth,
                behavior: 'smooth'
            });
            updateDots();
        }
        
        prevBtn.addEventListener('click', () => scrollToCard(currentIndex - 1));
        nextBtn.addEventListener('click', () => scrollToCard(currentIndex + 1));
        
        servicesCarousel.addEventListener('scroll', () => {
            const scrollPos = servicesCarousel.scrollLeft;
            const newIndex = Math.round(scrollPos / cardWidth);
            if (newIndex !== currentIndex) {
                currentIndex = newIndex;
                updateDots();
            }
        });
        
        let isDown = false;
        let startX;
        let scrollLeft;
        
        servicesCarousel.addEventListener('mousedown', (e) => {
            isDown = true;
            startX = e.pageX - servicesCarousel.offsetLeft;
            scrollLeft = servicesCarousel.scrollLeft;
        });
        
        servicesCarousel.addEventListener('mouseleave', () => { isDown = false; });
        servicesCarousel.addEventListener('mouseup', () => { isDown = false; });
        servicesCarousel.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - servicesCarousel.offsetLeft;
            const walk = (x - startX) * 2;
            servicesCarousel.scrollLeft = scrollLeft - walk;
        });
    }

    // CODE TYPEWRITER WITH TABS
    const codeContent = document.getElementById('codeContent');
    const codeTabs = document.querySelectorAll('.code-tab');
    
    const codeSnippets = {
        js: `const app = express();

app.get('/api/users', async (req, res) => {
    const users = await User.findAll();
    res.json({ success: true, data: users });
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});`,
        php: `<?php
class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return response()->json([
            'success' => true,
            'data' => $users
        ]);
    }
}`,
        py: `from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/users')
def get_users():
    users = User.query.all()
    return jsonify({
        'success': True,
        'data': [u.to_dict() for u in users]
    })`
    };
    
    if (codeContent && codeTabs.length > 0) {
        function typeCode(code) {
            codeContent.textContent = '';
            let i = 0;
            function typeChar() {
                if (i < code.length) {
                    codeContent.textContent += code[i];
                    i++;
                    setTimeout(typeChar, 20);
                }
            }
            typeChar();
        }
        
        typeCode(codeSnippets.js);
        
        codeTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                codeTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                typeCode(codeSnippets[tab.dataset.lang]);
            });
        });
    }

});
