
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - UnityDev</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Crafting Digital Excellence</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <!-- Mega Premium Notification -->
    <div class="notification-overlay" id="blogNotify">
        <div class="notification-flyer flyer-theme-blog">
            <div class="flyer-scanner"></div>
            <div class="flyer-bg-drawing">
                <svg viewBox="0 0 400 400">
                    <circle cx="200" cy="200" r="180" stroke="rgba(255,100,100,0.1)" stroke-width="1" fill="none" class="drawing-path" />
                    <rect x="100" y="100" width="200" height="200" stroke="rgba(255,100,100,0.05)" fill="none" transform="rotate(45 200 200)" />
                </svg>
            </div>
            <div class="flyer-illustration-container">
                <div class="illustration-orbit">
                    <div class="orbit-dot"></div>
                </div>
                <div class="illustration-main">
                    <svg viewBox="0 0 100 100" width="100" height="100">
                        <rect x="20" y="25" width="60" height="50" rx="5" fill="url(#blogGrad)" stroke="#fff" stroke-width="2" class="drawing-path" />
                        <line x1="30" y1="40" x2="70" y2="40" stroke="#fff" stroke-width="2" />
                        <line x1="30" y1="50" x2="70" y2="50" stroke="#fff" stroke-width="2" />
                        <line x1="30" y1="60" x2="55" y2="60" stroke="#fff" stroke-width="2" />
                        <defs>
                            <linearGradient id="blogGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#FF6464" />
                                <stop offset="100%" style="stop-color:#9657f6" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </div>
            <h3 class="flyer-title">Knowledge Base</h3>
            <p class="flyer-text">Deep insights for elite minds. Stay informed with our latest research and technical breakthroughs.</p>
            <button class="flyer-btn" onclick="closeNotification('blogNotify')">
                START READING
                <div class="btn-shine"></div>
            </button>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <img src="assets/images/logo.svg" alt="UnityDev Logo">
                    <h2>UNITYDEV</h2>
                </div>
                <div class="nav-menu" id="navMenu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="blog.php" class="active">Blog</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="index.php#contact">Contact</a></li>
                    </ul>
                    <div class="nav-buttons">
                        <a href="resume.php" class="btn-outline">Resume</a>
                        <a href="index.php#contact" class="btn-primary">Hire Me</a>
                    </div>
                </div>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
        <div class="container">
            <div class="blog-preview-content" style="margin-bottom: 2rem;">
                <div class="blog-animation">
                    <div class="rotating-sphere">
                        <div class="sphere-face front">BLOG</div>
                        <div class="sphere-face back">READ</div>
                        <div class="sphere-face left">LEARN</div>
                        <div class="sphere-face right">GROW</div>
                    </div>
                </div>
                <div class="blog-preview-text">
                    <h1 class="page-title">Our Blog</h1>
                    <p class="page-subtitle">Insights, Tutorials & Tech Trends</p>
                </div>
            </div>
        </div>
    </section>

    <section class="blog-featured">
        <div class="container">
            <div class="featured-post">
                <div class="featured-image">
                    <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&h=600&fit=crop" alt="Featured Post">
                    <div class="featured-badge">Featured Article</div>
                </div>
                <div class="featured-content">
                    <div class="post-meta">
                        <span><i class="fas fa-calendar"></i> Jan 10, 2026</span>
                        <span><i class="fas fa-clock"></i> 8 min read</span>
                        <span><i class="fas fa-tag"></i> Web Development</span>
                    </div>
                    <h2>The Future of Web Development: Trends to Watch in 2026</h2>
                    <p>Discover the cutting-edge technologies and frameworks that are shaping the future of web development. From AI-powered tools to next-gen frameworks, explore what's coming next in the world of coding.</p>
                    <a href="#" class="btn-primary">Read Full Article <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>

    <section class="blog-posts">
        <div class="container">
            <div class="blog-filters">
                <button class="filter-btn active" data-filter="all">All Posts</button>
                <button class="filter-btn" data-filter="web-dev">Web Development</button>
                <button class="filter-btn" data-filter="design">UI/UX Design</button>
                <button class="filter-btn" data-filter="tutorials">Tutorials</button>
                <button class="filter-btn" data-filter="tips">Tips & Tricks</button>
            </div>

            <div class="blog-grid">
                <article class="blog-card" data-category="web-dev">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">Web Development</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Jan 8, 2026</span>
                            <span><i class="fas fa-clock"></i> 5 min</span>
                        </div>
                        <h3>Building Scalable Web Applications with React</h3>
                        <p>Learn best practices for creating large-scale React applications that perform well and are easy to maintain.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>

                <article class="blog-card" data-category="design">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">UI/UX Design</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Jan 6, 2026</span>
                            <span><i class="fas fa-clock"></i> 7 min</span>
                        </div>
                        <h3>Modern UI Design Principles Every Developer Should Know</h3>
                        <p>Explore essential design principles that will elevate your user interfaces and create better user experiences.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>

                <article class="blog-card" data-category="tutorials">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">Tutorial</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Jan 4, 2026</span>
                            <span><i class="fas fa-clock"></i> 10 min</span>
                        </div>
                        <h3>Complete Guide to API Integration with Node.js</h3>
                        <p>Step-by-step tutorial on integrating third-party APIs into your Node.js applications effectively.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>

                <article class="blog-card" data-category="tips">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">Tips & Tricks</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Jan 2, 2026</span>
                            <span><i class="fas fa-clock"></i> 4 min</span>
                        </div>
                        <h3>10 VS Code Extensions That Boost Productivity</h3>
                        <p>Discover the must-have VS Code extensions that will make you a more efficient developer.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>

                <article class="blog-card" data-category="web-dev">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">Web Development</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Dec 30, 2024</span>
                            <span><i class="fas fa-clock"></i> 6 min</span>
                        </div>
                        <h3>Understanding JavaScript Async/Await</h3>
                        <p>Master asynchronous JavaScript with this comprehensive guide to async/await patterns.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>

                <article class="blog-card" data-category="design">
                    <div class="blog-card-image">
                        <img src="https://images.unsplash.com/photo-1558655146-d09347e92766?w=600&h=400&fit=crop" alt="Blog Post">
                        <div class="blog-category">UI/UX Design</div>
                    </div>
                    <div class="blog-card-content">
                        <div class="blog-meta">
                            <span><i class="fas fa-calendar"></i> Dec 28, 2024</span>
                            <span><i class="fas fa-clock"></i> 5 min</span>
                        </div>
                        <h3>Creating Responsive Designs That Actually Work</h3>
                        <p>Learn the secrets to building truly responsive designs that look great on every device.</p>
                        <a href="#" class="blog-read-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>
            </div>

            <div class="blog-pagination">
                <button class="pagination-btn"><i class="fas fa-chevron-left"></i> Previous</button>
                <div class="pagination-numbers">
                    <button class="page-num active">1</button>
                    <button class="page-num">2</button>
                    <button class="page-num">3</button>
                    <button class="page-num">4</button>
                </div>
                <button class="pagination-btn">Next <i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </section>

    <section class="blog-newsletter">
        <div class="container">
            <div class="newsletter-content">
                <div class="newsletter-icon">
                    <i class="fab fa-whatsapp"></i>
                </div>
                <div class="newsletter-text">
                    <h2>Get Updates on WhatsApp</h2>
                    <p>Get the latest articles, tutorials, and tips delivered straight to your WhatsApp</p>
                </div>
                <div class="newsletter-form">
                    <a href="https://wa.me/61468302435" class="btn-primary" style="display: inline-block; padding: 1rem 2rem; text-decoration: none;">
                        <i class="fab fa-whatsapp"></i> Connect on WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>UNITYDEV</h3>
                    <p>Full Stack Developer specializing in modern web applications and user-friendly designs.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="https://wa.me/61468302435"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
                <div class="footer-contact">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-envelope"></i> Odigieunity81@gmail.com</li>
                        <li><i class="fas fa-envelope"></i> bestakinyemi203@gmail.com</li>
                        <li><a href="https://wa.me/61468302435" style="color: inherit; text-decoration: none;"><i class="fas fa-phone"></i> +61 468 302 435</a></li>
                        <li><i class="fas fa-map-marker-alt"></i> California, United States</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 UnityDev. All Rights Reserved.</p>
                <button class="back-to-top" id="backToTop">
                    <i class="fas fa-arrow-up"></i>
                </button>
            </div>
        </div>
    </footer>

    <!-- Blog Modal -->
    <div class="blog-modal" id="blogModal">
        <div class="blog-modal-content">
            <div class="blog-modal-header">
                <h2 id="modalTitle"></h2>
                <button class="blog-modal-close" id="modalClose">&times;</button>
            </div>
            <div class="blog-modal-body" id="modalBody">
                <!-- Blog content will be inserted here -->
            </div>
        </div>
    </div>

    <!-- Floating WhatsApp Button -->
    <a href="https://wa.me/61468302435" class="whatsapp-float" target="_blank" aria-label="Contact us on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/blog.js"></script>
    <script src="assets/js/blog-content.js"></script>
</body>
</html>
