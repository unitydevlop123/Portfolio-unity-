
<?php
$reviewFile = 'storage/review.json';

// Ensure storage directory exists
if (!is_dir('storage')) {
    mkdir('storage', 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['reviewName'] ?? ''));
    $role = htmlspecialchars(trim($_POST['reviewRole'] ?? ''));
    $text = htmlspecialchars(trim($_POST['reviewText'] ?? ''));
    
    if (!empty($name) && !empty($role) && !empty($text)) {
        // Array of vibrant colors for avatar backgrounds
        $colors = ['0003ff', 'ff6b6b', '4ecdc4', '45b7d1', 'f9ca24', '6c5ce7', 'fd79a8', '00b894', 'e74c3c', '3498db', '2ecc71', 'f39c12', '9b59b6', '1abc9c', 'e67e22', '34495e'];
        $randomColor = $colors[array_rand($colors)];
        
        // Load existing reviews
        $reviews = [];
        if (file_exists($reviewFile)) {
            $content = file_get_contents($reviewFile);
            $reviews = json_decode($content, true) ?: [];
        }
        
        // Add new review
        $reviews[] = [
            'name' => $name,
            'role' => $role,
            'text' => $text,
            'color' => $randomColor,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Save to file
        file_put_contents($reviewFile, json_encode($reviews, JSON_PRETTY_PRINT));
    }
}

// Redirect back to homepage
header('Location: index.php');
exit;
