<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects - UnityDev Portfolio</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* PROJECT 4: PREMIUM CARD SHOWCASE */
        .project-4-container {
            margin-bottom: 5rem;
            padding: 3rem 0;
        }

        .project-4-header {
            text-align: center;
            margin-bottom: 2rem;
            animation: slideInDown 0.8s ease;
        }

        .project-4-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: #fff;
        }

        .project-4-header h2 {
            font-size: 2.2rem;
            color: white;
            margin-bottom: 0.5rem;
            line-height: 1.2;
        }

        .project-4-header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .project-4-showcase {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            background: linear-gradient(135deg, rgba(0, 3, 255, 0.08), rgba(68, 216, 189, 0.05));
            border: 1px solid rgba(0, 212, 255, 0.2);
            border-radius: 25px;
            padding: 3rem;
            animation: fadeInUp 0.8s ease;
        }

        @media (max-width: 768px) {
            .project-4-showcase {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
        }

        .project-4-content h3 {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 1.5rem;
            line-height: 1.3;
        }

        .project-4-content p {
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }

        .project-4-sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 768px) {
            .project-4-sections {
                grid-template-columns: 1fr;
            }
        }

        .project-4-section {
            margin-bottom: 0;
        }

        .project-4-section h5 {
            color: var(--accent-color);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .project-4-section h5 i {
            font-size: 1rem;
        }

        .project-4-section p {
            color: var(--text-secondary);
            line-height: 1.6;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .project-4-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .project-4-section ul li {
            color: var(--text-secondary);
            padding: 0.4rem 0;
            padding-left: 1.5rem;
            position: relative;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .project-4-section ul li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: var(--accent-color);
            font-weight: bold;
        }

        .project-4-tech {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
        }

        .project-4-tech span {
            background: linear-gradient(135deg, rgba(0, 3, 255, 0.15), rgba(68, 216, 189, 0.1));
            border: 1px solid rgba(0, 212, 255, 0.3);
            color: #00d4ff;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .project-4-tech span:hover {
            transform: translateY(-3px);
            background: linear-gradient(135deg, rgba(0, 3, 255, 0.25), rgba(68, 216, 189, 0.15));
            box-shadow: 0 5px 15px rgba(0, 212, 255, 0.2);
        }

        .project-4-hosting-note {
            background: rgba(68, 216, 189, 0.1);
            border-left: 4px solid var(--accent-color);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
        }

        .project-4-hosting-note p {
            color: var(--accent-color);
            font-size: 0.9rem;
            margin: 0;
        }

        .project-4-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .project-4-actions a {
            padding: 0.8rem 2rem;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.6rem;
            font-size: 0.95rem;
        }

        .btn-primary-project {
            background: linear-gradient(135deg, #0003ff, #44d8bd);
            color: white;
            box-shadow: 0 10px 30px rgba(0, 3, 255, 0.3);
        }

        .btn-primary-project:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(0, 3, 255, 0.4);
        }

        .btn-outline-project {
            border: 2px solid var(--accent-color);
            color: var(--accent-color);
            background: transparent;
        }

        .btn-outline-project:hover {
            background: var(--accent-color);
            color: var(--dark-bg);
            transform: translateY(-4px);
        }

        /* PROJECT 2: ADVANCED TABLE SHOWCASE */
        .project-2-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(255, 100, 100, 0.5), transparent);
            margin: 4rem 0;
        }

        .project-2-container {
            margin-bottom: 5rem;
            padding: 3rem 0;
        }

        .project-2-header {
            text-align: center;
            margin-bottom: 2rem;
            animation: slideInUp 0.8s ease;
        }

        .project-2-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #00c853, #00e676);
            color: #fff;
        }

        .project-2-header h2 {
            font-size: 2.2rem;
            color: white;
            margin-bottom: 0.5rem;
        }

        .project-2-header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .project-2-wrapper {
            background: linear-gradient(135deg, rgba(150, 87, 246, 0.08), rgba(255, 100, 100, 0.05));
            border: 1px solid rgba(255, 100, 100, 0.2);
            border-radius: 25px;
            overflow: hidden;
            animation: fadeInUp 0.8s ease 0.2s both;
        }

        .project-2-header-section {
            background: linear-gradient(135deg, rgba(150, 87, 246, 0.15), rgba(255, 100, 100, 0.1));
            padding: 2.5rem;
            border-bottom: 1px solid rgba(255, 100, 100, 0.2);
        }

        .project-2-header-section h3 {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 0.5rem;
        }

        .project-2-header-section p {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        .project-2-content {
            padding: 2.5rem;
        }

        .project-2-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2.5rem;
        }

        @media (max-width: 768px) {
            .project-2-grid {
                grid-template-columns: 1fr;
            }
        }

        .project-2-section {
            margin-bottom: 0;
        }

        .project-2-section h5 {
            color: #ff6464;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .project-2-section h5 i {
            font-size: 1rem;
        }

        .project-2-section p {
            color: var(--text-secondary);
            line-height: 1.6;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .project-2-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .project-2-section ul li {
            color: var(--text-secondary);
            padding: 0.4rem 0;
            padding-left: 1.5rem;
            position: relative;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .project-2-section ul li::before {
            content: '◆';
            position: absolute;
            left: 0;
            color: #ff6464;
            font-size: 0.6rem;
        }

        .project-2-tech {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
        }

        .project-2-tech span {
            background: rgba(255, 100, 100, 0.1);
            border: 1px solid rgba(255, 100, 100, 0.3);
            color: #ff9999;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .project-2-tech span:hover {
            transform: translateY(-3px);
            background: rgba(255, 100, 100, 0.2);
            box-shadow: 0 5px 15px rgba(255, 100, 100, 0.2);
        }

        .credentials-box {
            background: rgba(255, 215, 0, 0.1);
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1rem;
        }

        .credentials-box h6 {
            color: #ffd700;
            font-size: 0.85rem;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .credentials-box p {
            margin: 0.5rem 0;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        .credentials-box code {
            background: rgba(0, 0, 0, 0.3);
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-family: monospace;
            color: #fff;
        }

        .project-2-table {
            width: 100%;
            margin-bottom: 1.5rem;
            border-collapse: collapse;
            background: rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
        }

        .project-2-table th {
            background: linear-gradient(135deg, rgba(255, 100, 100, 0.2), rgba(150, 87, 246, 0.15));
            color: #ff6464;
            padding: 1rem 1.5rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid rgba(255, 100, 100, 0.3);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .project-2-table td {
            padding: 1rem 1.5rem;
            color: var(--text-secondary);
            border-bottom: 1px solid rgba(255, 100, 100, 0.1);
            font-size: 0.9rem;
        }

        .project-2-table tr:last-child td {
            border-bottom: none;
        }

        .project-2-table tr:hover {
            background: rgba(255, 100, 100, 0.08);
        }

        .project-2-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .btn-primary-project-2 {
            background: linear-gradient(135deg, #9657f6, #ff6464);
            color: white;
            box-shadow: 0 10px 30px rgba(255, 100, 100, 0.3);
        }

        .btn-primary-project-2:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(255, 100, 100, 0.4);
        }

        /* PROJECT 3: TIMELINE SHOWCASE */
        .project-3-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(255, 215, 0, 0.5), transparent);
            margin: 4rem 0;
        }

        .project-3-container {
            margin-bottom: 3rem;
            padding: 3rem 0;
        }

        .project-3-header {
            text-align: center;
            margin-bottom: 2rem;
            animation: slideInDown 0.8s ease 0.4s both;
        }

        .project-3-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #ff9800, #ffc107);
            color: #000;
        }

        .project-3-header h2 {
            font-size: 2.2rem;
            color: white;
            margin-bottom: 0.5rem;
        }

        .project-3-header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .project-3-timeline {
            position: relative;
            padding: 2rem 0;
        }

        .project-3-timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(180deg, rgba(255, 215, 0, 0.3), rgba(255, 152, 0, 0.1));
            transform: translateX(-50%);
        }

        @media (max-width: 768px) {
            .project-3-timeline::before {
                left: 30px;
            }
        }

        .timeline-item {
            margin-bottom: 3rem;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            align-items: center;
            animation: fadeInUp 0.8s ease;
        }

        .timeline-item:nth-child(even) {
            direction: rtl;
        }

        .timeline-item:nth-child(even) > * {
            direction: ltr;
        }

        @media (max-width: 768px) {
            .timeline-item {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .timeline-item:nth-child(even) {
                direction: ltr;
            }
        }

        .timeline-content {
            background: linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 152, 0, 0.05));
            padding: 2rem;
            border-radius: 15px;
            border: 1px solid rgba(255, 215, 0, 0.2);
            position: relative;
        }

        .timeline-content::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            background: linear-gradient(135deg, #ffd700, #ff9800);
            border: 3px solid var(--dark-bg);
            border-radius: 50%;
            right: -63px;
            top: 2rem;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
        }

        .timeline-item:nth-child(even) .timeline-content::after {
            right: auto;
            left: -63px;
        }

        @media (max-width: 768px) {
            .timeline-content::after {
                right: auto;
                left: -50px;
                top: 1rem;
            }

            .timeline-item:nth-child(even) .timeline-content::after {
                left: -50px;
            }
        }

        .timeline-content h4 {
            color: #ffd700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 0.8rem;
        }

        .timeline-content h3 {
            color: white;
            font-size: 1.3rem;
            margin-bottom: 1rem;
        }

        .timeline-content p {
            color: var(--text-secondary);
            line-height: 1.6;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .timeline-features {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
        }

        .timeline-feature-tag {
            background: rgba(255, 215, 0, 0.15);
            border: 1px solid rgba(255, 215, 0, 0.3);
            color: #ffd700;
            padding: 0.4rem 0.9rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .timeline-features ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .timeline-features ul li {
            color: var(--text-secondary);
            padding: 0.4rem 0;
            padding-left: 1.5rem;
            position: relative;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .timeline-features ul li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #ffd700;
            font-weight: bold;
        }

        .project-3-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 2rem;
        }

        .project-3-actions a {
            padding: 0.8rem 2rem;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.6rem;
            font-size: 0.95rem;
        }

        .btn-primary-project-3 {
            background: linear-gradient(135deg, #ffd700, #ff9800);
            color: #000;
            box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
        }

        .btn-primary-project-3:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(255, 215, 0, 0.4);
        }

        .btn-outline-project-3 {
            border: 2px solid #ffd700;
            color: #ffd700;
            background: transparent;
        }

        .btn-outline-project-3:hover {
            background: #ffd700;
            color: var(--dark-bg);
            transform: translateY(-4px);
        }

        .dev-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem 1.2rem;
            background: rgba(255, 152, 0, 0.1);
            border-radius: 8px;
            margin-top: 1rem;
            border-left: 3px solid #ff9800;
        }

        .dev-status i {
            color: #ff9800;
            animation: pulse 2s infinite;
        }

        .dev-status span {
            color: #ff9800;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* PROJECT 4: E-COMMERCE STORE */
        .project-1-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(76, 205, 196, 0.5), transparent);
            margin: 4rem 0;
        }

        .project-1-container {
            margin-bottom: 5rem;
            padding: 3rem 0;
        }

        .project-1-header {
            text-align: center;
            margin-bottom: 2rem;
            animation: slideInDown 0.8s ease;
        }

        .project-1-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #4ccdc4, #44af8d);
            color: #fff;
        }

        .project-1-header h2 {
            font-size: 2.2rem;
            color: white;
            margin-bottom: 0.5rem;
        }

        .project-1-header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .project-1-showcase {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            background: linear-gradient(135deg, rgba(76, 205, 196, 0.08), rgba(68, 216, 189, 0.05));
            border: 1px solid rgba(76, 205, 196, 0.2);
            border-radius: 25px;
            padding: 3rem;
            animation: fadeInUp 0.8s ease;
        }

        @media (max-width: 768px) {
            .project-1-showcase {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
        }

        .project-1-video {
            border-radius: 15px;
            overflow: hidden;
            background: rgba(0, 0, 0, 0.3);
            min-height: 400px;
        }

        .project-1-content h3 {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 1.5rem;
            line-height: 1.3;
        }

        .project-1-content p {
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }

        .project-1-sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 768px) {
            .project-1-sections {
                grid-template-columns: 1fr;
            }
        }

        .project-1-section {
            margin-bottom: 0;
        }

        .project-1-section h5 {
            color: #4ccdc4;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .project-1-section h5 i {
            font-size: 1rem;
        }

        .project-1-section p {
            color: var(--text-secondary);
            line-height: 1.6;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .project-1-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .project-1-section ul li {
            color: var(--text-secondary);
            padding: 0.4rem 0;
            padding-left: 1.5rem;
            position: relative;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .project-1-section ul li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #4ccdc4;
            font-weight: bold;
        }

        .project-1-tech {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
        }

        .project-1-tech span {
            background: linear-gradient(135deg, rgba(76, 205, 196, 0.15), rgba(68, 216, 189, 0.1));
            border: 1px solid rgba(76, 205, 196, 0.3);
            color: #4ccdc4;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .project-1-tech span:hover {
            transform: translateY(-3px);
            background: linear-gradient(135deg, rgba(76, 205, 196, 0.25), rgba(68, 216, 189, 0.15));
            box-shadow: 0 5px 15px rgba(76, 205, 196, 0.2);
        }

        .project-1-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .project-1-actions a {
            padding: 0.8rem 2rem;
            border-radius: 25px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.6rem;
            font-size: 0.95rem;
        }

        .btn-primary-project-1 {
            background: linear-gradient(135deg, #4ccdc4, #44af8d);
            color: white;
            box-shadow: 0 10px 30px rgba(76, 205, 196, 0.3);
        }

        .btn-primary-project-1:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(76, 205, 196, 0.4);
        }

        .btn-outline-project-1 {
            border: 2px solid #4ccdc4;
            color: #4ccdc4;
            background: transparent;
        }

        .btn-outline-project-1:hover {
            background: #4ccdc4;
            color: var(--dark-bg);
            transform: translateY(-4px);
        }

        /* ENHANCED ANIMATIONS */
        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* NEW GLOWING BADGE ANIMATION */
        @keyframes badgeGlow {
            0%, 100% {
                box-shadow: 0 0 10px rgba(0, 212, 255, 0.3), inset 0 0 10px rgba(0, 212, 255, 0.1);
            }
            50% {
                box-shadow: 0 0 20px rgba(0, 212, 255, 0.6), inset 0 0 15px rgba(0, 212, 255, 0.2);
            }
        }

        /* SHIMMER EFFECT FOR TECH TAGS */
        @keyframes shimmer {
            0% { background-position: -1000px 0; }
            100% { background-position: 1000px 0; }
        }

        /* BOUNCE ANIMATION FOR ICONS */
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        /* ROTATE ANIMATION FOR ICONS */
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* SLIDE IN LEFT */
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-40px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* SLIDE IN RIGHT */
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(40px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* SCALE UP WITH FADE */
        @keyframes scaleUp {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* GLOW PULSE FOR HIGHLIGHTS */
        @keyframes glowPulse {
            0%, 100% {
                box-shadow: 0 0 5px rgba(0, 212, 255, 0.2);
            }
            50% {
                box-shadow: 0 0 20px rgba(0, 212, 255, 0.5);
            }
        }

        /* STAGGER LIST ITEMS */
        @keyframes listSlideIn {
            from {
                opacity: 0;
                transform: translateX(-15px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* FLOAT ANIMATION */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
        }

        /* COLOR SHIFT ANIMATION */
        @keyframes colorShift {
            0%, 100% { color: var(--accent-color); }
            50% { color: rgba(68, 216, 189, 0.8); }
        }

        /* EXPAND HEIGHT */
        @keyframes expandHeight {
            from { max-height: 0; opacity: 0; }
            to { max-height: 500px; opacity: 1; }
        }

        /* ATTENTION JIGGLE */
        @keyframes jiggle {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(-2deg); }
            75% { transform: rotate(2deg); }
        }

        /* APPLY ANIMATIONS TO ELEMENTS */
        .project-4-badge {
            animation: badgeGlow 2.5s ease-in-out infinite, slideInDown 0.8s ease !important;
        }

        .project-2-badge {
            animation: slideInUp 0.8s ease, glowPulse 3s ease-in-out infinite;
        }

        .project-3-badge {
            animation: slideInDown 0.8s ease 0.4s both, glowPulse 3s ease-in-out 0.4s infinite;
        }

        .project-4-section h5 i {
            animation: bounce 2s infinite;
        }

        .project-2-section h5 i {
            animation: bounce 2.2s infinite;
        }

        .timeline-content h4 i {
            animation: rotate 20s linear infinite;
            opacity: 0.8;
        }

        .project-4-section ul li {
            animation: listSlideIn 0.6s ease forwards;
        }

        .project-4-section ul li:nth-child(1) { animation-delay: 0.1s; }
        .project-4-section ul li:nth-child(2) { animation-delay: 0.2s; }
        .project-4-section ul li:nth-child(3) { animation-delay: 0.3s; }
        .project-4-section ul li:nth-child(4) { animation-delay: 0.4s; }
        .project-4-section ul li:nth-child(5) { animation-delay: 0.5s; }
        .project-4-section ul li:nth-child(6) { animation-delay: 0.6s; }
        .project-4-section ul li:nth-child(7) { animation-delay: 0.7s; }

        .project-2-section ul li {
            animation: listSlideIn 0.6s ease forwards;
        }

        .project-2-section ul li:nth-child(1) { animation-delay: 0.1s; }
        .project-2-section ul li:nth-child(2) { animation-delay: 0.2s; }
        .project-2-section ul li:nth-child(3) { animation-delay: 0.3s; }
        .project-2-section ul li:nth-child(4) { animation-delay: 0.4s; }
        .project-2-section ul li:nth-child(5) { animation-delay: 0.5s; }
        .project-2-section ul li:nth-child(6) { animation-delay: 0.6s; }

        .timeline-features ul li {
            animation: listSlideIn 0.6s ease forwards;
        }

        .project-4-tech span {
            animation: float 2.5s ease-in-out infinite;
        }

        .project-4-tech span:nth-child(1) { animation-delay: 0s; }
        .project-4-tech span:nth-child(2) { animation-delay: 0.2s; }
        .project-4-tech span:nth-child(3) { animation-delay: 0.4s; }
        .project-4-tech span:nth-child(4) { animation-delay: 0.6s; }
        .project-4-tech span:nth-child(5) { animation-delay: 0.8s; }
        .project-4-tech span:nth-child(6) { animation-delay: 1s; }

        .project-2-tech span {
            animation: float 2.7s ease-in-out infinite;
        }

        .project-2-tech span:nth-child(1) { animation-delay: 0s; }
        .project-2-tech span:nth-child(2) { animation-delay: 0.2s; }
        .project-2-tech span:nth-child(3) { animation-delay: 0.4s; }
        .project-2-tech span:nth-child(4) { animation-delay: 0.6s; }
        .project-2-tech span:nth-child(5) { animation-delay: 0.8s; }
        .project-2-tech span:nth-child(6) { animation-delay: 1s; }
        .project-2-tech span:nth-child(7) { animation-delay: 1.2s; }

        .timeline-feature-tag {
            animation: scaleUp 0.5s ease forwards;
        }

        .timeline-item:nth-child(1) .timeline-content { animation: slideInLeft 0.7s ease; }
        .timeline-item:nth-child(2) .timeline-content { animation: slideInRight 0.7s ease 0.1s both; }
        .timeline-item:nth-child(3) .timeline-content { animation: slideInLeft 0.7s ease 0.2s both; }
        .timeline-item:nth-child(4) .timeline-content { animation: slideInRight 0.7s ease 0.3s both; }

        .project-4-hosting-note {
            animation: expandHeight 0.6s ease;
        }

        .dev-status {
            animation: float 3s ease-in-out infinite;
        }

        .credentials-box {
            animation: scaleUp 0.5s ease 0.2s both;
        }

        /* ENHANCED HOVER ANIMATIONS */
        .project-4-tech span:hover {
            animation: jiggle 0.4s ease;
        }

        .project-2-tech span:hover {
            animation: jiggle 0.4s ease;
        }

        .timeline-feature-tag:hover {
            animation: colorShift 1s ease;
        }

        .project-4-actions a {
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .project-2-actions a {
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .project-3-actions a {
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .project-4-showcase {
            animation: fadeInUp 0.8s ease, float 6s ease-in-out 1s infinite !important;
        }

        .project-2-wrapper {
            animation: fadeInUp 0.8s ease 0.2s both, float 6s ease-in-out 1s infinite !important;
        }

        .privacy-notice {
            background: linear-gradient(135deg, rgba(150, 87, 246, 0.1), rgba(0, 3, 255, 0.1));
            border: 1px solid rgba(150, 87, 246, 0.3);
            border-radius: 15px;
            padding: 1.5rem 2rem;
            margin-bottom: 3rem;
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            animation: fadeInUp 0.8s ease forwards;
        }
        
        .privacy-notice i {
            font-size: 1.5rem;
            color: var(--secondary-color);
            margin-top: 0.2rem;
        }
        
        .privacy-notice-content h4 {
            color: var(--secondary-color);
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }
        
        .privacy-notice-content p {
            color: var(--text-secondary);
            font-size: 0.95rem;
            line-height: 1.6;
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Crafting Digital Excellence</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <!-- Animated Background -->
    <div class="projects-bg-shapes">
        <div class="floating-shape"></div>
        <div class="floating-shape"></div>
        <div class="floating-shape"></div>
    </div>

    <!-- Mega Premium Notification -->
    <div class="notification-overlay" id="projectsNotify">
        <div class="notification-flyer flyer-theme-projects">
            <div class="flyer-scanner"></div>
            <div class="flyer-bg-drawing">
                <svg viewBox="0 0 400 400">
                    <path class="drawing-path" d="M50,50 L350,50 L350,350 L50,350 Z" stroke="rgba(68,216,189,0.1)" stroke-width="1" fill="none" />
                    <path d="M200,0 L200,400 M0,200 L400,200" stroke="rgba(68,216,189,0.05)" fill="none" />
                </svg>
            </div>
            <div class="flyer-illustration-container">
                <div class="illustration-orbit">
                    <div class="orbit-dot"></div>
                </div>
                <div class="illustration-main">
                    <svg viewBox="0 0 100 100" width="100" height="100">
                        <path class="drawing-path" d="M20,80 L50,20 L80,80 L50,65 Z" fill="url(#projectsGrad)" stroke="#fff" stroke-width="2" />
                        <defs>
                            <linearGradient id="projectsGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#44D8BD" />
                                <stop offset="100%" style="stop-color:#9657f6" />
                            </linearGradient>
                        </defs>
                        <circle cx="50" cy="45" r="10" fill="rgba(255,255,255,0.2)" />
                    </svg>
                </div>
            </div>
            <h3 class="flyer-title">Innovation Hub</h3>
            <p class="flyer-text">Step into the future. Our portfolio showcases the highest level of engineering and digital craftsmanship.</p>
            <button class="flyer-btn" onclick="closeNotification('projectsNotify')">
                EXPLORE WORK
                <div class="btn-shine"></div>
            </button>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <img src="assets/images/logo.svg" alt="UnityDev Logo">
                    <h2>UNITYDEV</h2>
                </div>
                <div class="nav-menu" id="navMenu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php" class="active">Projects</a></li>
                        <li><a href="blog.php">Blog</a></li>
                        <li><a href="index.php#contact">Contact</a></li>
                    </ul>
                    <div class="nav-buttons">
                        <a href="resume.php" class="btn-outline">Resume</a>
                        <a href="index.php#contact" class="btn-primary">Hire Me</a>
                    </div>
                </div>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="dots-line"></div>
        </div>
        <div class="container">
            <h1 class="page-title">Live Project Portfolio</h1>
            <p class="page-subtitle">Real-world projects delivered to satisfied clients worldwide</p>
        </div>
    </section>

    <section class="projects-section">
        <div class="container">
            
            <!-- Privacy Notice -->
            <div class="privacy-notice">
                <i class="fas fa-shield-alt"></i>
                <div class="privacy-notice-content">
                    <h4>Client Privacy Notice</h4>
                    <p>Most clients prefer their projects not to be displayed publicly due to privacy and business concerns. The demos shown below are public reference copies hosted on subdomains, while the final websites are live on clients' primary domains. Please respect the confidentiality of these showcased works.</p>
                </div>
            </div>

            <!-- PROJECT 4: CARD-BASED SHOWCASE (CYAN/TEAL) -->
            <div class="project-1-container">
                <div class="project-1-header">
                    <span class="project-1-badge"><i class="fas fa-globe"></i> International Client</span>
                    <h2>UnityTech Data - Business Portfolio Website</h2>
                    <p>Professional web presence for a technology consulting firm</p>
                </div>

                <div class="project-1-showcase">
                    <div class="project-1-content">
                        <h3>Building Tomorrow's Digital Solutions</h3>
                        
                        <div class="project-1-sections">
                            <div class="project-1-section">
                                <h5><i class="fas fa-briefcase"></i> Project Overview</h5>
                                <p>Developed a modern, professional online presence for an international technology consulting client. The website serves as the primary digital storefront, showcasing their services, expertise, and generating qualified business leads from potential clients worldwide.</p>
                            </div>
                            
                            <div class="project-1-section">
                                <h5><i class="fas fa-user-tie"></i> My Role</h5>
                                <p><strong>Sole Full-Stack Developer</strong> - Handled complete front-end design, back-end logic, database integration, and deployment. Delivered the project within a 2-week timeline while maintaining high quality standards.</p>
                            </div>
                            
                            <div class="project-1-section">
                                <h5><i class="fas fa-star"></i> Key Features</h5>
                                <ul>
                                    <li>Responsive, mobile-first design that looks stunning on all devices</li>
                                    <li>Dynamic service pages with interactive elements</li>
                                    <li>Professional portfolio/case study showcase</li>
                                    <li>Fully functional contact and inquiry system</li>
                                    <li>SEO optimized for better search visibility</li>
                                    <li>Fast loading speeds and optimized performance</li>
                                </ul>
                            </div>
                            
                            <div class="project-1-section">
                                <h5><i class="fas fa-bullseye"></i> The Challenge</h5>
                                <p>Create a cost-effective, fast-loading website that the client could easily update independently. The design needed to convey professionalism and trustworthiness while being completed within a tight 2-week deadline.</p>
                            </div>
                        </div>

                        <div class="project-1-section">
                            <h5><i class="fas fa-code"></i> Technical Stack</h5>
                            <div class="project-1-tech">
                                <span>PHP</span>
                                <span>JavaScript</span>
                                <span>Custom CSS</span>
                                <span>Firebase Real-time</span>
                                <span>Firebase Auth</span>
                                <span>Responsive Design</span>
                                <span>AJAX</span>
                                <span>Security</span>
                            </div>
                        </div>

                        <div class="project-1-section">
                            <h5><i class="fas fa-trophy"></i> Results Achieved</h5>
                            <ul>
                                <li>Successfully launched within deadline</li>
                                <li>Client reported increased lead generation</li>
                                <li>Mobile traffic increased by 40%</li>
                                <li>Page load time under 3 seconds</li>
                            </ul>
                        </div>

                        <div class="project-1-hosting-note">
                            <p><i class="fas fa-info-circle"></i> <strong>Hosting Note:</strong> The final website is live on the client's primary domain. This link is a public reference copy to showcase the design and functionality developed.</p>
                        </div>

                        <div class="project-1-actions">
                            <a href="https://unitytechdata.rf.gd" target="_blank" class="btn-primary-project">
                                <i class="fas fa-external-link-alt"></i> Visit Live Demo
                            </a>
                            <a href="index.php#contact" class="btn-outline-project">
                                <i class="fas fa-envelope"></i> Request Similar Project
                            </a>
                        </div>
                    </div>

                    <div></div>
                </div>
            </div>

            <!-- PROJECT 2: TABLE SHOWCASE (PURPLE/RED) -->
            <div class="project-2-divider"></div>
            <div class="project-2-container">
                <div class="project-2-header">
                    <span class="project-2-badge"><i class="fas fa-check-circle"></i> Live & Active</span>
                    <h2>WePay-You - Investment & Gaming Platform</h2>
                    <p>Full-featured earning platform with real-time wallet system and gaming center</p>
                </div>

                <div class="project-2-wrapper">
                    <div class="project-2-header-section">
                        <h3>Advanced Investment Platform with Gaming Integration</h3>
                        <p>A comprehensive investment and earning platform featuring a sophisticated real-time wallet system, multiple investment packages (Starter, Regular, VIP), daily task completion rewards, and an engaging Game Center with various interactive games for users to earn bonuses.</p>
                    </div>

                    <div class="project-2-content">
                        <div class="project-2-grid">
                            <div class="project-2-section">
                                <h5><i class="fas fa-briefcase"></i> Project Overview</h5>
                                <p>A comprehensive investment and earning platform featuring a sophisticated real-time wallet system, multiple investment packages (Starter, Regular, VIP), daily task completion rewards, and an engaging Game Center with various interactive games for users to earn bonuses.</p>
                            </div>
                            
                            <div class="project-2-section">
                                <h5><i class="fas fa-user-tie"></i> My Role</h5>
                                <p><strong>Lead Full-Stack Developer</strong> - Architected and built the entire platform from ground up, including complex financial transaction systems, secure user authentication, real-time wallet management, and gamification features.</p>
                            </div>

                            <div class="project-2-section">
                                <h5><i class="fas fa-star"></i> Platform Features</h5>
                                <ul>
                                    <li><strong>Smart Wallet System:</strong> Main wallet, locked funds, and bonus wallet with real-time updates</li>
                                    <li><strong>Investment Packages:</strong> Tiered investment options (Starter, Regular, VIP) with varying returns</li>
                                    <li><strong>Daily Tasks/Orders:</strong> Complete tasks to earn rewards and bonuses</li>
                                    <li><strong>Lucky Order System:</strong> Special bonus opportunities for active users</li>
                                    <li><strong>Game Center:</strong> Spin & Win, Number Guessing, Coin Flip games</li>
                                    <li><strong>Transaction History:</strong> Complete tracking of deposits, withdrawals, investments</li>
                                    <li><strong>Secure Profiles:</strong> PIN protection and verification system</li>
                                    <li><strong>Referral Program:</strong> Earn from inviting new users</li>
                                </ul>
                            </div>

                            <div class="project-2-section">
                                <h5><i class="fas fa-bullseye"></i> The Challenge</h5>
                                <p>Build a secure, scalable financial platform that handles real money transactions with absolute precision. Required implementing complex business logic for investments, automated payouts, and ensuring 100% accuracy in all financial calculations.</p>
                            </div>
                        </div>

                        <div class="project-2-section">
                            <h5><i class="fas fa-code"></i> Technical Stack</h5>
                            <div class="project-2-tech">
                                <span>PHP</span>
                                <span>JavaScript</span>
                                <span>Firebase Real-time</span>
                                <span>Firebase Auth</span>
                                <span>Real-time APIs</span>
                                <span>Payment Integration</span>
                                <span>Security Systems</span>
                            </div>
                        </div>

                        <div class="project-2-section">
                            <h5><i class="fas fa-lock"></i> Security Features</h5>
                            <ul>
                                <li>Secure PIN protection for transactions</li>
                                <li>Email verification system</li>
                                <li>Encrypted data storage</li>
                                <li>Anti-fraud detection measures</li>
                            </ul>
                        </div>

                        <div class="credentials-box">
                            <h6><i class="fas fa-key"></i> Demo Access</h6>
                            <p style="font-size: 0.95rem; color: var(--text-default); margin-bottom: 0.5rem;">Experience the platform firsthand with full features available. If you'd like to explore this investment platform or discuss building a similar solution for your business, I'm here to help!</p>
                            <p style="font-size: 0.85rem; color: var(--text-secondary);"><i class="fas fa-handshake"></i> <strong>Want exclusive demo access?</strong> Contact me through the form below, and I'll set you up with personalized credentials and a complete walkthrough of this platform's capabilities.</p>
                        </div>

                        <h4 style="color: #ff6464; margin-top: 2rem; margin-bottom: 1.5rem; text-transform: uppercase; letter-spacing: 1px; font-size: 0.9rem;">Platform Features & Specifications</h4>
                        <table class="project-2-table">
                            <thead>
                                <tr>
                                    <th>Feature</th>
                                    <th>Specification</th>
                                    <th>Status</th>
                                    <th>Performance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Real-Time Wallet</strong></td>
                                    <td>Live balance updates</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Instant</td>
                                </tr>
                                <tr>
                                    <td><strong>Investment System</strong></td>
                                    <td>3 tier packages</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Auto-compound</td>
                                </tr>
                                <tr>
                                    <td><strong>Task Rewards</strong></td>
                                    <td>Daily completion bonuses</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Real-time</td>
                                </tr>
                                <tr>
                                    <td><strong>Game Center</strong></td>
                                    <td>5+ interactive games</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Optimized</td>
                                </tr>
                                <tr>
                                    <td><strong>Referral System</strong></td>
                                    <td>Multi-level commissions</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Automated</td>
                                </tr>
                                <tr>
                                    <td><strong>Admin Panel</strong></td>
                                    <td>Full platform control</td>
                                    <td><span style="color: #44d8bd;">✓ Active</span></td>
                                    <td>Real-time</td>
                                </tr>
                            </tbody>
                        </table>

                        <div class="project-2-actions">
                            <a href="https://wepay-you.gt.tc" target="_blank" class="btn-primary-project btn-primary-project-2">
                                <i class="fas fa-external-link-alt"></i> Visit Live Platform
                            </a>
                            <a href="index.php#contact" class="btn-outline-project">
                                <i class="fas fa-envelope"></i> Request Similar Project
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PROJECT 3: TIMELINE SHOWCASE (GOLD/ORANGE) -->
            <div class="project-3-divider"></div>
            <div class="project-3-container">
                <div class="project-3-header">
                    <span class="project-3-badge"><i class="fas fa-tools"></i> In Development</span>
                    <h2>Nexora - Next-Generation Social Media Platform</h2>
                    <p>A powerful, feature-rich social networking platform built from scratch</p>
                </div>

                <div class="project-3-timeline">
                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4><i class="fas fa-briefcase"></i> Project Vision</h4>
                            <h3>Foundation & Architecture</h3>
                            <p>Nexora is an ambitious next-generation social media platform designed to revolutionize how people connect, share, and interact online. This is a personal passion project that showcases my ability to architect and build complex, scalable social networking systems from the ground up.</p>
                            <div class="timeline-features">
                                <span class="timeline-feature-tag">User System</span>
                                <span class="timeline-feature-tag">Core Architecture</span>
                                <span class="timeline-feature-tag">Database Design</span>
                            </div>
                        </div>
                        <div></div>
                    </div>

                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4><i class="fas fa-code"></i> My Role</h4>
                            <h3>Solo Development & Leadership</h3>
                            <p><strong>Solo Founder & Developer</strong> - This project is built entirely by me without company support. I am handling all aspects including system architecture, front-end design, back-end development, database design, and infrastructure planning.</p>
                            <div class="timeline-features">
                                <span class="timeline-feature-tag">Full Stack</span>
                                <span class="timeline-feature-tag">Architecture</span>
                                <span class="timeline-feature-tag">Leadership</span>
                            </div>
                        </div>
                        <div></div>
                    </div>

                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4><i class="fas fa-star"></i> Planned Features</h4>
                            <h3>Complete Social Experience</h3>
                            <div class="timeline-features">
                                <ul>
                                    <li><strong>User Profiles:</strong> Rich, customizable user profiles with media galleries</li>
                                    <li><strong>Social Feed:</strong> Algorithm-powered content discovery and sharing</li>
                                    <li><strong>Real-time Messaging:</strong> Instant messaging with read receipts and media sharing</li>
                                    <li><strong>Groups & Communities:</strong> Create and join interest-based communities</li>
                                    <li><strong>Content Creation:</strong> Posts, stories, videos, and live streaming</li>
                                    <li><strong>Notifications:</strong> Real-time push notifications for all activities</li>
                                    <li><strong>Privacy Controls:</strong> Granular privacy settings for all content</li>
                                    <li><strong>Mobile Responsive:</strong> Full functionality on all devices</li>
                                </ul>
                            </div>
                        </div>
                        <div></div>
                    </div>

                    <div class="timeline-item">
                        <div class="timeline-content">
                            <h4><i class="fas fa-lightbulb"></i> Technical Excellence</h4>
                            <h3>Enterprise-Scale Development</h3>
                            <p><strong>The Challenge:</strong> Building a social media platform requires solving complex technical challenges including real-time data synchronization, scalable database architecture, content moderation systems, and handling high concurrent user loads - all while maintaining a smooth user experience.</p>
                            <p><strong>Why This Project:</strong> Nexora demonstrates my capability to conceptualize, architect, and build enterprise-level applications. It showcases advanced skills in database design, real-time systems, and creating seamless user experiences at scale.</p>
                            <div class="dev-status">
                                <i class="fas fa-circle"></i>
                                <span>Currently paused - Seeking development support/investment to continue</span>
                            </div>
                        </div>
                        <div></div>
                    </div>
                </div>

                <div class="project-3-actions">
                    <a href="http://nexora.org.imi.lat" target="_blank" class="btn-primary-project btn-primary-project-3">
                        <i class="fas fa-eye"></i> Preview Development Version
                    </a>
                    <a href="index.php#contact" class="btn-outline-project-3">
                        <i class="fas fa-handshake"></i> Interested in Supporting?
                    </a>
                </div>
            </div>

        </div>
    </section>

    <!-- PROJECT 4: UNITY E-COMMERCE STORE -->
    <section class="projects-section">
        <div class="container">
            <div class="project-4-divider"></div>

            <div class="project-4-container">
                <div class="project-4-header">
                    <span class="project-4-badge">
                        <i class="fas fa-shopping-bag"></i> Featured Project
                    </span>
                    <h2>Unity E-commerce Store</h2>
                    <p>Redefining fashion with quality, style, and sustainability</p>
                </div>

                <div class="project-4-showcase">
                    <div class="project-4-video">
                        <div style="width:100%;aspect-ratio:9/16;position:relative;max-width:500px;margin:0 auto;">
                            <iframe src="https://player.vimeo.com/video/1148239238?badge=0&autopause=1&player_id=0&app_id=58479" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share" referrerpolicy="strict-origin-when-cross-origin" style="position:absolute;top:0;left:0;width:100%;height:100%;border-radius:15px;" title="Unitydevlop -e commerce"></iframe>
                        </div>
                        <script src="https://player.vimeo.com/api/player.js"></script>
                    </div>

                    <div class="project-4-content">
                        <h3>Full-Stack E-Commerce Platform</h3>
                        <p>I built a complete, modern e-commerce website from scratch called Unity. It's a full online store that sells everything from clothes and shoes to electronics and lifestyle products. This project demonstrates my ability to create professional, feature-rich web applications that deliver real value.</p>

                        <div class="project-4-sections">
                            <div class="project-4-section">
                                <h5><i class="fas fa-star"></i> Key Features</h5>
                                <ul>
                                    <li><strong>1. Professional Navigation:</strong> Home, Shop, Sale, Brands, Live Support, About, Blog, Size Guide, FAQ, and Track Order with integrated search</li>
                                    <li><strong>2. User Dashboard:</strong> Profile, Orders, Wishlist, Payment Methods, Gift Cards, Rewards, and Settings</li>
                                    <li><strong>3. Product System:</strong> Complete product listings with pricing, discounts, ratings, and Add to Cart functionality</li>
                                    <li><strong>4. Shopping Cart:</strong> Full cart management with checkout process</li>
                                    <li><strong>Responsive Design:</strong> Fully responsive across all devices</li>
                                </ul>
                            </div>

                            <div class="project-4-section">
                                <h5><i class="fas fa-code"></i> Technical Stack</h5>
                                <div class="project-4-tech">
                                    <span>HTML5</span>
                                    <span>CSS3</span>
                                    <span>JavaScript</span>
                                    <span>PHP</span>
                                    <span>Firebase Real-time</span>
                                    <span>Firebase Auth</span>
                                    <span>Security</span>
                                </div>
                                <h5 style="margin-top: 1.5rem;"><i class="fas fa-briefcase"></i> My Role</h5>
                                <p>I was the solo full-stack developer. I designed the entire interface, built all pages and components, programmed the user account system, managed product listings, implemented the shopping cart functionality, and connected everything to the database.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="project-4-actions">
                    <a href="#" class="btn-primary-project-1">
                        <i class="fas fa-eye"></i> View Project
                    </a>
                    <a href="index.php#contact" class="btn-outline-project-1">
                        <i class="fas fa-envelope"></i> Get Similar Solution
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Have a Project in Mind?</h2>
                <p>Let's collaborate and bring your ideas to life with cutting-edge technology and creative solutions. Whether you need a simple website or a complex platform, I deliver quality results.</p>
                <div class="cta-buttons">
                    <a href="index.php#contact" class="btn-primary">Start Your Project</a>
                    <a href="resume.php" class="btn-outline">View My Resume</a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>UNITYDEV</h3>
                    <p>Full Stack Developer specializing in modern web applications and user-friendly designs.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="https://wa.me/61468302435"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.php#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="blog.php">Blog</a></li>
                    </ul>
                </div>
                <div class="footer-contact">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-envelope"></i> Odigieunity81@gmail.com</li>
                        <li><i class="fas fa-envelope"></i> bestakinyemi203@gmail.com</li>
                        <li><a href="https://wa.me/61468302435" style="color: inherit; text-decoration: none;"><i class="fas fa-phone"></i> +61 468 302 435</a></li>
                        <li><i class="fas fa-map-marker-alt"></i> California, United States</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 UnityDev. All Rights Reserved.</p>
                <button class="back-to-top" id="backToTop">
                    <i class="fas fa-arrow-up"></i>
                </button>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp Button -->
    <a href="https://wa.me/61468302435" class="whatsapp-float" target="_blank" aria-label="Contact us on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="assets/js/script.js"></script>
</body>
</html>
