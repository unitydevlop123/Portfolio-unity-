from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import json
import os

app = Flask(__name__, static_folder='.')
CORS(app)

STORAGE_FILE = 'storage/review.jons'

@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/api/reviews', methods=['GET'])
def get_reviews():
    try:
        if os.path.exists(STORAGE_FILE):
            with open(STORAGE_FILE, 'r') as f:
                reviews = json.load(f)
                return jsonify(reviews)
        return jsonify([])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/reviews', methods=['POST'])
def add_review():
    try:
        review_data = request.json
        
        reviews = []
        if os.path.exists(STORAGE_FILE):
            with open(STORAGE_FILE, 'r') as f:
                reviews = json.load(f)
        
        reviews.append(review_data)
        
        with open(STORAGE_FILE, 'w') as f:
            json.dump(reviews, f, indent=2)
        
        return jsonify({'success': True, 'message': 'Review added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    os.makedirs('storage', exist_ok=True)
    if not os.path.exists(STORAGE_FILE):
        with open(STORAGE_FILE, 'w') as f:
            json.dump([], f)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
