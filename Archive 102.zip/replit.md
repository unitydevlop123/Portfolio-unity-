# UnityDev Portfolio

## Overview

This is a professional developer portfolio website showcasing web development services and projects. The application features a modern, visually striking design with animations, a blog section, client testimonials, and a review system. It's built as a hybrid application with both a React/TypeScript frontend and legacy static HTML/CSS/JavaScript pages, served by an Express backend with optional Flask support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The project uses a dual frontend approach:

1. **Modern React Frontend** (in `client/` directory)
   - Built with React and TypeScript
   - Uses Vite as the build tool with hot module replacement
   - Styling via Tailwind CSS (using the new `@tailwindcss/vite` plugin)
   - UI components from Radix UI primitives with shadcn/ui patterns
   - Form handling with React Hook Form and Zod validation
   - Data fetching with TanStack React Query
   - Path aliases: `@` for client/src, `@shared` for shared code, `@assets` for attached assets

2. **Legacy Static Frontend** (in root `assets/` directory)
   - Traditional HTML/CSS/JavaScript files
   - Custom CSS with CSS variables for theming (dark theme with blue/purple gradients)
   - Vanilla JavaScript for interactivity (blog filtering, loading screens, navigation)
   - Blog content management system in JavaScript

### Backend Architecture

1. **Primary: Express/Node.js Server** (in `server/` directory)
   - TypeScript-based Express server
   - Development via tsx, production builds to CommonJS
   - Drizzle ORM for database operations (schema likely in `shared/` or `server/`)
   - Session management with connect-pg-simple for PostgreSQL

2. **Alternative: Flask Server** (server.py in root)
   - Simple Python Flask server for static file serving
   - JSON file-based review storage (`storage/review.jons`)
   - REST API endpoints for reviews (`/api/reviews`)

### Data Storage

- **Primary**: PostgreSQL database with Drizzle ORM
- **Fallback**: JSON file storage for reviews (Flask implementation)
- Database migrations via `drizzle-kit push`

### Build Process

- Vite builds the React frontend to `dist/public`
- Custom build script at `script/build.ts`
- Production server runs from `dist/index.cjs`

## External Dependencies

### Frontend Libraries
- **UI Framework**: React with Radix UI component primitives
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Forms**: React Hook Form with Zod resolver
- **Data Fetching**: TanStack React Query
- **Date Handling**: date-fns
- **Command Menu**: cmdk

### Backend Services
- **Database**: PostgreSQL (via Drizzle ORM)
- **Session Store**: connect-pg-simple for Express sessions

### Development Tools
- **Build**: Vite, TypeScript, tsx
- **Database Migrations**: drizzle-kit
- **Error Handling**: @replit/vite-plugin-runtime-error-modal

### Optional Python Stack
- Flask for alternative server
- flask-cors for CORS handling