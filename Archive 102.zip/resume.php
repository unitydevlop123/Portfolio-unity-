
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume - UnityDev</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Premium Loading Screen -->
    <div class="loading-screen" id="loadingScreen">
        <div class="loader-bg-particles">
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
            <div class="loader-particle"></div>
        </div>
        <div class="loader-glow-orb"></div>
        <div class="loader-main">
            <div class="loader-ring">
                <div class="loader-ring-inner"></div>
            </div>
            <div class="loader-brand">
                <span class="loader-letter" style="--i:1">U</span>
                <span class="loader-letter" style="--i:2">N</span>
                <span class="loader-letter" style="--i:3">I</span>
                <span class="loader-letter" style="--i:4">T</span>
                <span class="loader-letter" style="--i:5">Y</span>
                <span class="loader-letter" style="--i:6">D</span>
                <span class="loader-letter" style="--i:7">E</span>
                <span class="loader-letter" style="--i:8">V</span>
            </div>
        </div>
        <div class="loader-tagline">Crafting Digital Excellence</div>
        <div class="loader-progress">
            <div class="loader-progress-bar"></div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <img src="assets/images/logo.svg" alt="UnityDev Logo">
                    <h2>UNITYDEV</h2>
                </div>
                <div class="nav-menu" id="navMenu">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.html#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="index.html#contact">Contact</a></li>
                    </ul>
                    <div class="nav-buttons">
                        <a href="resume.php" class="btn-outline active">Resume</a>
                        <a href="index.html#contact" class="btn-primary">Hire Me</a>
                    </div>
                </div>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="dots-line"></div>
        </div>
        <div class="container">
            <h1 class="page-title">Professional Resume</h1>
            <p class="page-subtitle">My journey in full-stack development and UI/UX design</p>
        </div>
    </section>

    <section class="resume-content">
        <div class="container">
            <div class="resume-modern-container">
                
                <!-- Header Card with Image -->
                <div class="resume-header-card">
                    <div class="header-image">
                        <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400" alt="Developer Workspace">
                    </div>
                    <div class="header-info">
                        <h1>UNITYDEV</h1>
                        <h2>Full Stack Developer & UI/UX Designer</h2>
                        <div class="contact-details">
                            <span><i class="fas fa-map-marker-alt"></i> California, United States</span>
                            <span><i class="fas fa-envelope"></i> Odigieunity81@gmail.com</span>
                            <span><a href="https://wa.me/61468302435" style="color: inherit; text-decoration: none;"><i class="fas fa-phone"></i> +61 468 302 435</a></span>
                        </div>
                        <a href="#" class="btn-primary"><i class="fas fa-download"></i> Download PDF</a>
                    </div>
                </div>

                <!-- Professional Summary - Left Aligned Card -->
                <div class="resume-card summary-card">
                    <div class="card-icon">
                        <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400" alt="Code on screen">
                    </div>
                    <div class="card-content">
                        <h2><i class="fas fa-user-tie"></i> Professional Summary</h2>
                        <p>Experienced Full Stack Developer with 3+ years of expertise in building modern, scalable web applications. Proficient in frontend technologies like React, Vue.js, and Angular, as well as backend development with Node.js, Python, and PHP. I specialize in creating seamless user experiences and delivering high-quality code. Strong problem-solving skills with a proven track record of successful project delivery and 25+ completed projects for clients worldwide.</p>
                    </div>
                </div>

                <!-- Work Experience - Grid Layout -->
                <div class="resume-card experience-card">
                    <h2><i class="fas fa-briefcase"></i> Work Experience</h2>
                    
                    <div class="experience-grid">
                        <div class="exp-item">
                            <div class="exp-image">
                                <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400" alt="Coding workspace">
                            </div>
                            <div class="exp-details">
                                <h3>Senior Full Stack Developer</h3>
                                <div class="position">Freelance / Remote</div>
                                <div class="date"><i class="fas fa-calendar"></i> June 2022 - Present</div>
                                <ul>
                                    <li>Led development of 25+ web applications for clients worldwide</li>
                                    <li>Specialized in full-stack development with modern JavaScript frameworks and Firebase</li>
                                    <li>Implemented responsive designs and optimized application performance</li>
                                    <li>Maintained 98% client satisfaction rate with on-time project delivery</li>
                                </ul>
                            </div>
                        </div>

                        <div class="exp-item">
                            <div class="exp-image">
                                <img src="https://images.unsplash.com/photo-1629654297299-c8506221ca97?w=400" alt="Tech workspace">
                            </div>
                            <div class="exp-details">
                                <h3>Full Stack Developer</h3>
                                <div class="position">Tech Solutions Inc., California</div>
                                <div class="date"><i class="fas fa-calendar"></i> June 2023 - December 2023</div>
                                <ul>
                                    <li>Developed and maintained enterprise-level web applications</li>
                                    <li>Built RESTful APIs and integrated third-party services</li>
                                    <li>Improved application performance by 40% through optimization</li>
                                    <li>Mentored junior developers and conducted code reviews</li>
                                </ul>
                            </div>
                        </div>

                        <div class="exp-item">
                            <div class="exp-image">
                                <img src="https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400" alt="Programming setup">
                            </div>
                            <div class="exp-details">
                                <h3>Frontend Developer</h3>
                                <div class="position">Digital Agency, California</div>
                                <div class="date"><i class="fas fa-calendar"></i> January 2023 - May 2023</div>
                                <ul>
                                    <li>Created responsive and user-friendly interfaces for various clients</li>
                                    <li>Implemented modern CSS animations and transitions</li>
                                    <li>Ensured cross-browser compatibility and mobile responsiveness</li>
                                    <li>Delivered 10+ successful client projects</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Education - Right Aligned Card -->
                <div class="resume-card education-card">
                    <div class="card-content">
                        <h2><i class="fas fa-graduation-cap"></i> Education</h2>
                        <h3>Bachelor of Science in Computer Science</h3>
                        <div class="position">University of California</div>
                        <div class="date"><i class="fas fa-calendar"></i> 2018 - 2022</div>
                        <p>Graduated with First Class Honors. Specialized in Software Engineering and Web Development. Completed final year project on "Scalable Web Application Architecture".</p>
                    </div>
                    <div class="card-icon">
                        <img src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400" alt="Education books">
                    </div>
                </div>

                <!-- Technical Skills - Masonry Layout -->
                <div class="resume-card skills-card">
                    <h2><i class="fas fa-code"></i> Technical Skills</h2>
                    
                    <div class="skills-masonry">
                        <div class="skill-category frontend-skill">
                            <div class="skill-image">
                                <img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400" alt="Frontend Development">
                            </div>
                            <h3><i class="fas fa-laptop-code"></i> Frontend Development</h3>
                            <p>HTML5, CSS3, JavaScript, TypeScript, React.js, Vue.js, Angular, Next.js, Tailwind CSS, Bootstrap, SASS, Redux, Responsive Design</p>
                        </div>

                        <div class="skill-category backend-skill">
                            <div class="skill-image">
                                <img src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400" alt="Backend Development">
                            </div>
                            <h3><i class="fas fa-server"></i> Backend Development</h3>
                            <p>Node.js, Express.js, Python, Django, PHP, Laravel, RESTful APIs, GraphQL, WebSockets, Microservices</p>
                        </div>

                        <div class="skill-category database-skill">
                            <div class="skill-image">
                                <img src="https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400" alt="Database Tools">
                            </div>
                            <h3><i class="fas fa-database"></i> Database & Tools</h3>
                            <p>MongoDB, MySQL, PostgreSQL, Firebase, Redis, Git, GitHub, Docker, AWS, Heroku, Vercel, CI/CD, Agile/Scrum</p>
                        </div>

                        <div class="skill-category design-skill">
                            <div class="skill-image">
                                <img src="https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400" alt="Design Tools">
                            </div>
                            <h3><i class="fas fa-palette"></i> Design & Other</h3>
                            <p>UI/UX Design, Figma, Adobe XD, Photoshop, SEO Optimization, Performance Optimization, Testing (Jest, Cypress)</p>
                        </div>
                    </div>
                </div>

                <!-- Achievements - Card Grid -->
                <div class="resume-card achievements-card">
                    <h2><i class="fas fa-trophy"></i> Key Achievements</h2>
                    
                    <div class="achievements-grid">
                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <h4>10+ Projects</h4>
                            <p>Successfully delivered with 98% client satisfaction rate</p>
                        </div>

                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-rocket"></i>
                            </div>
                            <h4>40% Performance Boost</h4>
                            <p>Reduced application load time through optimization</p>
                        </div>

                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <h4>$300K+ Transactions</h4>
                            <p>Built e-commerce platform processing high volume</p>
                        </div>

                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-code-branch"></i>
                            </div>
                            <h4>8+ Open Source</h4>
                            <p>Contributed to open-source projects on GitHub</p>
                        </div>

                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <h4>5+ Developers Mentored</h4>
                            <p>Guided junior developers in web development</p>
                        </div>

                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <i class="fas fa-microphone"></i>
                            </div>
                            <h4>2 Tech Conferences</h4>
                            <p>Speaker on modern web development topics</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Work Together?</h2>
                <p>Let's discuss how I can help bring your project to life with my skills and experience.</p>
                <div class="cta-buttons">
                    <a href="index.html#contact" class="btn-primary">Contact Me</a>
                    <a href="projects.php" class="btn-outline">View Projects</a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>UNITYDEV</h3>
                    <p>Full Stack Developer specializing in modern web applications and user-friendly designs.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="https://wa.me/61468302435"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.html#services">Services</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
                <div class="footer-contact">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-envelope"></i> Odigieunity81@gmail.com</li>
                        <li><i class="fas fa-envelope"></i> bestakinyemi203@gmail.com</li>
                        <li><a href="https://wa.me/61468302435" style="color: inherit; text-decoration: none;"><i class="fas fa-phone"></i> +61 468 302 435</a></li>
                        <li><i class="fas fa-map-marker-alt"></i> California, United States</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 UnityDev. All Rights Reserved.</p>
                <button class="back-to-top" id="backToTop">
                    <i class="fas fa-arrow-up"></i>
                </button>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp Button -->
    <a href="https://wa.me/61468302435" class="whatsapp-float" target="_blank" aria-label="Contact us on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script src="assets/js/script.js"></script>
</body>
</html>
